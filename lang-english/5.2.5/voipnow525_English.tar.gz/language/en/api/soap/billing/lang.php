<?php

// English language file for SOAP methods
// Maintained by 4PSA
// docs@4psa.com
// VoipNow 5.2.5

// Modified: $DateTime$
// Revision: $Revision$


	$msg_arr['soap2_err_800'] = 'Invalid charging method. Here are the values available: fixed, inherit.';
	$msg_arr['soap2_err_801'] = 'One or several fixed charging values are not valid.';
	$msg_arr['soap2_err_802'] = 'One or several inherited charging values are not valid.';
	$msg_arr['soap2_err_804'] = 'Invalid limit for external outgoing calls. Value must be a real number with 14 digits maximum. (e.g. 75.5 or 80)';
	$msg_arr['soap2_err_805'] = 'Invalid limit for external incoming calls. Value must be a real number with 14 digits maximum. (e.g. 75.5 or 80)';
	$msg_arr['soap2_err_806'] = 'Invalid outgoing over-usage ratio or outgoing over-usage minutes. The outgoing over-usage ratio must be numeric, bigger than or equal to 0 and smaller than or equal to 8,388,607. The outgoing over-usage minutes must be numeric, bigger than or equal to 0 and smaller than or equal to 2147483647. (e.g. 3 or 15)';
	$msg_arr['soap2_err_808'] = 'One or several external outgoing minutes definitions available are not valid.';
	$msg_arr['soap2_err_809'] = 'One or several external outgoing charge definitions available are not valid.';
	$msg_arr['soap2_err_810'] = 'Invalid external incoming call cost. Value must be a real number with 15 digits maximum. (e.g. 75.5 or 80)';
	$msg_arr['soap2_err_811'] = 'Invalid local call cost. Value must be a real number with 14 digits maximum. (e.g. 75.5 or 80)';
	$msg_arr['soap2_err_812'] = 'Invalid extended local call cost. Value must be a real number with 14 digits maximum. (e.g. 75.5 or 80)';
	$msg_arr['soap2_err_813'] = 'Invalid charging plan name. Value must be a string of 3 to 255 characters.';
	$msg_arr['soap2_err_814'] = 'Time interval \'Anytime\' requires that you add external outgoing minutes. If you do not want to use \'Anytime\', you can set 0 minutes.';
	$msg_arr['soap2_err_815'] = 'The \'charge outgoing indivisible for the first number of seconds\' option is invalid. Value must be a number bigger than or equal to 1 and smaller than or equal to 600. (e.g. 3 or 15)';
	$msg_arr['soap2_err_816'] = 'The \'charge external incoming indivisible for the first number of seconds\' option is invalid. Value must be numeric, bigger than or equal to 1 and smaller than or equal to 600. (e.g. 3 or 15)';
	$msg_arr['soap2_err_817'] = 'The \'charge every\' for incoming calls option is invalid. Value must be numeric, bigger than or equal to 1 and smaller than or equal to 300. (e.g. 3 or 15)';
	$msg_arr['soap2_err_818'] = 'The \'charge every\' for outgoing calls option is invalid. Value must be numeric, higher than or equal to 1, and smaller than or equal to 300.(e.g. 3 or 15)';
	$msg_arr['soap2_err_819'] = 'You do not have the permission to access this area. Global billing is disabled.';
	$msg_arr['soap2_err_821'] = 'Invalid charging plan type. Here are the values available: prepaid or postpaid.';
	$msg_arr['soap2_err_822'] = 'Invalid initial incoming credit. Value must be a real number with 14 digits maximum. (e.g. 75.5 or 80)';
	$msg_arr['soap2_err_823'] = 'Invalid initial outgoing credit. Value must be a real number with 14 digits maximum. (e.g. 75.5 or 80)';
	$msg_arr['soap2_err_825'] = 'Invalid outgoing money limit/call credit. Value must be a real number with 14 digits maximum. (e.g. 75.5 or 80)';
	$msg_arr['soap2_err_826'] = 'Invalid incoming money limit/call credit. Value must be a real number with 14 digits maximum. (e.g. 75.5 or 80)';
	$msg_arr['soap2_err_826'] = 'Invalid incoming money limit/call credit. Value must be a real number with 14 digits maximum. (e.g. 75.5 or 80)';
	$msg_arr['soap2_err_827'] = 'Included minutes are invalid. Value must be numeric and smaller than 2147483647.';
	$msg_arr['soap2_err_828'] = 'Unable to update recharges. At least one of the limits must have a positive numeric value.';
	$msg_arr['soap2_err_829'] = 'Unable to update recharges. Incoming and outgoing calls are not allowed.';
	$msg_arr['soap2_err_830'] = 'Invalid order number. Value must be numeric.';
	$msg_arr['soap2_err_831'] = 'Permission to modify charging plan details denied. This charging plan is associated to a product in {app_name} Automation.';
	$msg_arr['soap2_err_832'] = 'User charging plan type for this request is invalid.';
	$msg_arr['soap2_err_844'] = 'Permission to modify or add charging plan denied. This action is not permitted for the selected user';

	// destination exception
	$msg_arr['soap2_err_833'] = 'Invalid request. Please fill in a free minutes package or specific charging for this area code.';
	$msg_arr['soap2_err_834'] = 'Invalid area code. Value must be numeric and contain less than 32 digits.';
	$msg_arr['soap2_err_835'] = 'Invalid area code description. Value cannot contain more 128 characters.';
	$msg_arr['soap2_err_836'] = 'Invalid initial charge amount. Value must be numeric, bigger than 0 and cannot contain more than 14 digits.';
	$msg_arr['soap2_err_837'] = 'Invalid initial charge time interval. Value must be numeric, bigger than 1 and smaller than 999999.';
	$msg_arr['soap2_err_838'] = 'Invalid periodic/call charge amount. Value must be numeric, bigger than 0 and cannot contain more than 14 digits.';
	$msg_arr['soap2_err_839'] = 'Invalid periodic charge time interval. Value must be numeric, bigger than 1 and smaller than 999999.';
	$msg_arr['soap2_err_840'] = 'Invalid setup charge amount. Value must be numeric, bigger than 1 and smaller than 999999.';
	$msg_arr['soap2_err_841'] = 'Invalid charging plan package. Value must be a string of no more than 255 characters.';
	$msg_arr['soap2_err_842'] = 'Invalid setup charge amount. Value must be numeric and cannot contain more than 14 digits.';
	$msg_arr['soap2_err_843'] = 'Invalid setup charge amount. Value must be numeric and cannot contain more than 14 digits.';

?>
