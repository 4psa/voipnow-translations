<?php

// English language file for CallAPI
// Maintained by 4PSA
// docs@4psa.com
// VoipNow 5.2.5

// Modified: $DateTime$
// Revision: $Revision$

	$msg_arr = array();

	/* Service exception */
	$msg_arr['uapi_err_msg_998'] = 'An internal server error occurred. Please contact the Administrator.';
	$msg_arr['uapi_err_msg_999'] = 'The license is invalid. Please contact the Administrator.';
	$msg_arr['uapi_err_msg_1554'] = 'The body of the request is invalid';
    $msg_arr['uapi_err_msg_1555'] = 'The request is invalid';

	/* Service exception */
	$msg_arr['uapi_err_msg_1050'] = 'The operation requested is invalid or not implemented.';
	$msg_arr['uapi_err_msg_1003'] = 'The operation could not be completed.';

	// Token related exceptions
	$msg_arr['uapi_err_msg_1100'] = 'Value supplied in the URI-Fragment as userId is invalid. The parameter must reference the Id of an user or can be set to @owner, @me or @viewer.';
	$msg_arr['uapi_err_msg_1101'] = 'Value supplied in the URI-Fragment as extension is invalid. The parameter must reference the number of an existing extension or can be set to @self.';
	$msg_arr['uapi_err_msg_1102'] = 'You are not authorized to use this request.';
	$msg_arr['uapi_err_msg_1103'] = 'The App you are using is not authorized to use this request.';

	$msg_arr['uapi_err_msg_3751'] = 'The access token is missing or invalid.';
	$msg_arr['uapi_err_msg_3750'] = 'The request is invalid.';
	$msg_arr['uapi_err_msg_3952'] = 'The requested service is not implemented.';
	$msg_arr['uapi_err_msg_3953'] = 'The service encountered an internal error. Please contact the Administrator. Reference code: ';
	$msg_arr['uapi_err_msg_3853'] = 'Value supplied in sortOrder parameter is missing or invalid. The parameter must be set to one of the values: ascending or descending.';
	$msg_arr['uapi_err_msg_3853'] = 'Value supplied in sortOrder parameter is missing or invalid. The parameter must be set to one of the values: ascending or descending.';
	$msg_arr['uapi_err_msg_3851'] = 'Value supplied in startIndex parameter is missing or invalid. The parameter must be set to a numeric value, higher or equal with 0.';
	$msg_arr['uapi_err_msg_3852'] = 'Value supplied in count parameter is missing or invalid. The parameter must be set to a numeric value lower than 5000.';
	$msg_arr['uapi_err_msg_3854'] = 'Value supplied in filterOp parameter is missing or invalid. The parameter must be set to one of the values: contains, equals, startsWith or present.';

	/* PhoneCall related exceptions */
	$msg_arr['uapi_err_msg_1201'] = 'Value supplied in maxInParking parameter is missing or invalid. The parameter must be set to a numeric value. It represents the number of seconds a call can stay in the parking lot.';
	$msg_arr['uapi_err_msg_1202'] = 'Value supplied in recFormat parameter is missing or invalid. The parameter must be set to one of the following value: wav or wav49.';
	$msg_arr['uapi_err_msg_1203'] = 'Value supplied in extension parameter is missing or invalid. The parameter must be set to the number of a Callback extension that must be owned by the user.';
	$msg_arr['uapi_err_msg_1204'] = 'Value supplied in extension parameter is missing or invalid. The parameter must be set to the number of a Conference extension that must be owned by the user. Default has the same value as the source parameter.';
	$msg_arr['uapi_err_msg_1205'] = 'Value supplied in extension parameter is missing or invalid. The parameter must be set to the number of a Phone Terminal extension that must be owned by the user. Default has the same value as the source parameter.';
	$msg_arr['uapi_err_msg_1206'] = 'Value supplied in private parameter is missing or invalid. The parameter must be set to 0 for non private calls or 1 for private calls.';
	$msg_arr['uapi_err_msg_1207'] = 'Value supplied in callDuration parameter is missing or invalid. The parameter must be set to a numeric value and represents the number of seconds a phone call must last.';
	$msg_arr['uapi_err_msg_1208'] = 'Value supplied in phoneCallId from the URI-Fragment is invalid. The parameter must be set to an alpha-numeric value and reference an existing phone call.';
	$msg_arr['uapi_err_msg_1209'] = 'Value supplied in phoneCallViewId parameter is missing or invalid. The parameter must reference a view of the phone call identfied by the phoneCallId given in the URI-Fragment.';
	$msg_arr['uapi_err_msg_1210'] = 'Value supplied in phoneNumber parameter is missing or invalid. The parameter must be set to a value consisting of digits and optional a + character.';
	$msg_arr['uapi_err_msg_1211'] = 'Value supplied in source parameter is missing or invalid. The parameter must be set to a list of extended or short extension numbers or public phone numbers.';
	$msg_arr['uapi_err_msg_1212'] = 'Value supplied in destination parameter is missing or invalid. The parameter must be set to a list of extended or short extension numbers or public phone numbers.';
	$msg_arr['uapi_err_msg_1213'] = 'Value supplied in waitForPickup parameter is missing or invalid. The parameter must be numeric and higher than 0.';
	$msg_arr['uapi_err_msg_1214'] = 'Value supplied in sendCallTo parameter is missing or invalid. The parameter must be set to the number of a Phone Terminal extension.';
	$msg_arr['uapi_err_msg_1215'] = 'Value supplied in source parameter is missing or invalid. The parameter must be set to the number of an existing conference extension.';
	$msg_arr['uapi_err_msg_1226'] = 'Value supplied in callerId parameter is missing or invalid. The parameter must be set to a value with the format: John Doe <+3334444>.';
	$msg_arr['uapi_err_msg_1227'] = 'Value supplied in transferNumber parameter is missing or invalid. The parameter must be set to the value of a phone number.';
	$msg_arr['uapi_err_msg_1228'] = 'Value supplied in transferFromNumber parameter is missing or invalid. The parameter must be set to the value of a phone number.';
	$msg_arr['uapi_err_msg_1216'] = 'Value supplied in fields parameter is missing or invalid. The parameter must be set to a value consisting of the name of the possible PhoneCall fields separated by a comma (e.g. extension,id,answered).';
	$msg_arr['uapi_err_msg_1217'] = 'Value supplied in count parameter is missing or invalid. The parameter must be set to a numeric value lower than 5000.';
	$msg_arr['uapi_err_msg_1218'] = 'Value supplied in filterBy parameter is missing or invalid. The parameter must be set to the name of a PhoneCall field.';
	$msg_arr['uapi_err_msg_1219'] = 'Value supplied in filterOp parameter is missing or invalid. The parameter must be set to one of the values: contains, equals, startsWith or present.';
	$msg_arr['uapi_err_msg_1220'] = 'Value supplied in filterValue parameter is missing or invalid. The parameter must be set to a string value.';
	$msg_arr['uapi_err_msg_1221'] = 'Value supplied in sortOrder parameter is missing or invalid. The parameter must be set to one of the values: ascending or descending.';
	$msg_arr['uapi_err_msg_1222'] = 'Value supplied in startIndex parameter is missing or invalid. The parameter must be set to a numeric value, higher or equal with 0.';
	$msg_arr['uapi_err_msg_1223'] = 'Value supplied in pin parameter is missing or invalid.';
	$msg_arr['uapi_err_msg_1224'] = 'Value supplied in number parameter is missing or invalid.';
	$msg_arr['uapi_err_msg_1225'] = 'Value supplied in allowPublicTransfer parameter is missing or invalid. The parameter must be set to true or false.';
    $msg_arr['uapi_err_msg_1229'] = 'You are not allowed to set the callerid field.';
    $msg_arr['uapi_err_msg_1230'] = 'Value supplied in nonce parameter is invalid.';

	//Phone call events
	$msg_arr['uapi_err_msg_1301'] = 'Value supplied in type parameter is missing or invalid. The parameter must be set to one of the following value: 0 for DialIn, 1 for DialOut and 2 for Hangup.';
	$msg_arr['uapi_err_msg_1302'] = 'Value supplied in id parameter is invalid. The parameter must be set to an unique alpha-numeric 32 characters long string.';
	$msg_arr['uapi_err_msg_1303'] = 'Value supplied in method parameter is missing or invalid. The parameter must be set to one of the following value: 0 for GET or 1 for POST.';
	$msg_arr['uapi_err_msg_1304'] = 'Value supplied in note parameter is missing or invalid. It must be string and 1024 characters long.';
	$msg_arr['uapi_err_msg_1305'] = 'Value supplied in request URL parameter is missing or invalid. It must be a valid HTTP URL.';
	$msg_arr['uapi_err_msg_1306'] = 'Value supplied in status parameter is missing or invalid. The parameter must be set to one of the following value: 0 for enabled or 1 for disabled.';
	$msg_arr['uapi_err_msg_1307'] = 'Value supplied in the URI-Fragment as extension is invalid. The parameter must reference the number of an existing extension and cannot be set to @self.';
	$msg_arr['uapi_err_msg_1308'] = 'Failed to add the extension phone call event.';
	$msg_arr['uapi_err_msg_1309'] = 'Failed to edit the extension phone call event.';
	$msg_arr['uapi_err_msg_1310'] = 'Failed to list the extension phone call event.';
	$msg_arr['uapi_err_msg_1311'] = 'Failed to delete the extension phone call event.';
	$msg_arr['uapi_err_msg_1312'] = 'Value supplied in the URI-Fragment as eventId is invalid. The parameter must reference an existing phone call event.';
	$msg_arr['uapi_err_msg_1313'] = 'You are not allowed to manage the phone call events.';
	$msg_arr['uapi_err_msg_1314'] = 'Value supplied in fields parameter is missing or invalid. The parameter must be set to a value consisting of the name of the possible PhoneCall fields separated by a comma (e.g. method,url,status).';
	$msg_arr['uapi_err_msg_1315'] = 'Value supplied in count parameter is missing or invalid. The parameter must be set to a numeric value lower than 5000.';
	$msg_arr['uapi_err_msg_1316'] = 'Value supplied in filterBy parameter is missing or invalid. The parameter must be set to the name of a PhoneCallEvent field.';
	$msg_arr['uapi_err_msg_1317'] = 'Value supplied in filterOp parameter is missing or invalid. The parameter must be set to one of the values: contains, equals, startsWith or present.';
	$msg_arr['uapi_err_msg_1318'] = 'Value supplied in filterValue parameter is missing or invalid. The parameter must be set to a string value.';
	$msg_arr['uapi_err_msg_1319'] = 'Value supplied in sortOrder parameter is missing or invalid. The parameter must be set to one of the values: ascending or descending.';
	$msg_arr['uapi_err_msg_1320'] = 'Value supplied in startIndex parameter is missing or invalid. The parameter must be set to a numeric value, higher or equal with 0.';

	//Fax execeptions
	$msg_arr['uapi_err_msg_1401'] = 'Value supplied in the recipients parameter is missing or invalid. Any phone number, including extension numbers can be a recipient. There can\'t be more recipients than the maximum number set up in the system.';
	$msg_arr['uapi_err_msg_1402'] = 'Value supplied in sender parameter is invalid. The parameter must be set to the name and email of the person sending the fax.';
	$msg_arr['uapi_err_msg_1403'] = 'Value supplied in approved parameter is missing or invalid. The parameter must be set to one of the following values: 0 for not apporved, 1 for approved.';
	$msg_arr['uapi_err_msg_1404'] = 'One of the files that must be sent as fax are invalid. Allowed file types are: jpg, tif, pdf and txt.';
	$msg_arr['uapi_err_msg_1405'] = 'Failed to send the fax because the number of files that can be sent was exceeded.';
	$msg_arr['uapi_err_msg_1406'] = 'Failed to send the fax due to an internal error.';
	$msg_arr['uapi_err_msg_1407'] = 'Value supplied in the URI-Fragment as extension is invalid. The parameter must reference the number of an existing Phone Terminal extension and cannot be set to @self.';

	//CDR exception
	$msg_arr['uapi_err_msg_1501'] = 'Value supplied in the URI-Fragment as userId is invalid. The parameter must reference the Id of an user or can be set to @me or @viewer.';
	$msg_arr['uapi_err_msg_1502'] = 'Value supplied in startDate parameter is invalid. The format should be ISO ISO 8601 YYYY-MM-DDThh:mm:ss.';
	$msg_arr['uapi_err_msg_1503'] = 'Value supplied in endDate parameter is invalid. The format should be ISO ISO 8601 YYYY-MM-DDThh:mm:ss.';
	$msg_arr['uapi_err_msg_1504'] = 'Value supplied in source parameter is invalid. The parameter must be set to any extension number or a public phone number.';
	$msg_arr['uapi_err_msg_1505'] = 'Value supplied in destination parameter is invalid. The parameter must be set to any extension number or a public phone number.';
	$msg_arr['uapi_err_msg_1506'] = 'Value supplied in flow parameter is invalid.';
	$msg_arr['uapi_err_msg_1507'] = 'Value supplied in disposition parameter is invalid.';
	$msg_arr['uapi_err_msg_1515'] = 'Value supplied in saveStartDate parameter is invalid. The format should be ISO ISO 8601 YYYY-MM-DDThh:mm:ss.';
	$msg_arr['uapi_err_msg_1516'] = 'Value supplied in saveEndDate parameter is invalid. The format should be ISO ISO 8601 YYYY-MM-DDThh:mm:ss.';

	$msg_arr['uapi_err_msg_1508'] = 'Value supplied in fields parameter is missing or invalid. The parameter must be set to a value of consisting of the name of the possible PhoneCall fields separated by a comma.';
	$msg_arr['uapi_err_msg_1514'] = 'Value supplied in count parameter is missing or invalid. The parameter must be set to a numeric value lower than 5000.';
	$msg_arr['uapi_err_msg_1509'] = 'Value supplied in filterBy parameter is missing or invalid. The parameter must be set to the name of a field used by CRD.';
	$msg_arr['uapi_err_msg_1510'] = 'Value supplied in filterOp parameter is missing or invalid. The parameter must be set to one of the values: contains, equals, startsWith or present.';
	$msg_arr['uapi_err_msg_1511'] = 'Value supplied in filterValue parameter is missing or invalid. The parameter must be set to a string value.';
	$msg_arr['uapi_err_msg_1512'] = 'Value supplied in sortOrder parameter is missing or invalid. The parameter must be set to one of the values: ascending or descending.';
	$msg_arr['uapi_err_msg_1513'] = 'Value supplied in startIndex parameter is missing or invalid. The parameter must be set to a numeric value, higher or equal with 0.';

	//Presence Exceptions
	$msg_arr['uapi_err_msg_1601'] = 'Value supplied in the URI-Fragment as extension is invalid. The parameter must reference the number of an existing Phone Terminal extension or can be set to @self.';
	$msg_arr['uapi_err_msg_1602'] = 'Value supplied in fields parameter is missing or invalid. The parameter must be set to a value of consisting of the name of the possible Presence fields separated by a comma (e.g. extension, id, answered).';
	$msg_arr['uapi_err_msg_1603'] = 'Value supplied in count parameter is missing or invalid. The parameter must be set to a numeric value lower than 5000.';
	$msg_arr['uapi_err_msg_1604'] = 'Value supplied in filterBy parameter is missing or invalid. The parameter must be set to the name of a Presence field.';
	$msg_arr['uapi_err_msg_1605'] = 'Value supplied in filterOp parameter is missing or invalid. The parameter must be set to one of the values: contains, equals, startsWith or present.';
	$msg_arr['uapi_err_msg_1606'] = 'Value supplied in filterValue parameter is missing or invalid. The parameter must be set to a string value.';
	$msg_arr['uapi_err_msg_1607'] = 'Value supplied in sortOrder parameter is missing or invalid. The parameter must be set to one of the values: ascending or descending.';
	$msg_arr['uapi_err_msg_1608'] = 'Value supplied in startIndex parameter is missing or invalid. The parameter must be set to a numeric value, higher or equal with 0.';

	//Queue Agent exceptions
	$msg_arr['uapi_err_msg_1701'] = 'Value supplied in status parameter is missing or invalid. The parameter can take the values: 0 for Logged Out, 1 for Online, 2 for Paused.';
	$msg_arr['uapi_err_msg_1702'] = 'Value supplied in the URI-Fragment as extension is invalid. The parameter must reference the number of an existing Queue extension and cannot be set to @self.';
	$msg_arr['uapi_err_msg_1703'] = 'Value supplied in the URI-Fragment as agent Id is invalid. The parameter must reference the number of an existing Queue agent or a public number';
	$msg_arr['uapi_err_msg_1704'] = 'Failed to change the status of the Queue agent.';
	$msg_arr['uapi_err_msg_1705'] = 'Value supplied in fields parameter is missing or invalid. The parameter must be set to a value of consisting of the name of the possible Agent fields separated by a comma (e.g. extension, id, answered).';
	$msg_arr['uapi_err_msg_1707'] = 'Value supplied in count parameter is missing or invalid. The parameter must be set to a numeric value lower than 5000.';
	$msg_arr['uapi_err_msg_1708'] = 'Value supplied in filterBy parameter is missing or invalid. The parameter must be set to the name of a Agent field.';
	$msg_arr['uapi_err_msg_1709'] = 'Value supplied in filterOp parameter is missing or invalid. The parameter must be set to one of the values: contains, equals, startsWith or present.';
	$msg_arr['uapi_err_msg_1710'] = 'Value supplied in filterValue parameter is missing or invalid. The parameter must be set to a string value.';
	$msg_arr['uapi_err_msg_1711'] = 'Value supplied in sortOrder parameter is missing or invalid. The parameter must be set to one of the values: ascending or descending.';
	$msg_arr['uapi_err_msg_1712'] = 'Value supplied in startIndex parameter is missing or invalid. The parameter must be set to a numeric value, higher or equal with 0.';
	$msg_arr['uapi_err_msg_1713'] = 'Failed to change the number of the Queue agent.';


	// Config exceptions
	$msg_arr['uapi_err_msg_1801'] = 'You are not authorized to use this request.';
	$msg_arr['uapi_err_msg_1800'] = 'Value supplied in extensionNumber parameter is missing or invalid. The parameter must be set to the number of a Phone Terminal extension.';
	$msg_arr['uapi_err_msg_1802'] = 'One of the value supplied in the sipPreferences parameter for supported codecs is invalid.';
    $msg_arr['uapi_err_msg_1804'] = 'Invalid Media encryption. Here are the values available: none, sdes, dtls.';
	$msg_arr['lbl_intern'] = 'System internal';

?>