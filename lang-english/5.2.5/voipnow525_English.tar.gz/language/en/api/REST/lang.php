<?php

// English language file for REST interface
// Maintained by 4PSA
// docs@4psa.com
// VoipNow 5.2.5

// Modified: $DateTime$
// Revision: $Revision$

$msg_arr['exception_REST_1000'] = 'REST server validation schema could not be loaded!';

$msg_arr['exception_REST_2000'] = 'REST request handler class could not be found!';
$msg_arr['exception_REST_2001'] = 'REST request handler function could not be found!';
$msg_arr['exception_REST_2002'] = 'REST request handler function could not be found!';
$msg_arr['exception_REST_2003'] = 'Both function and class REST request handlers found for this request!';
$msg_arr['exception_REST_2004'] = 'REST request initiator authentication handler class could not be found!';

$msg_arr['exception_REST_3000'] = 'REST request method could not be found!';

$msg_arr['exception_REST_4000'] = 'REST input parameter \'{param}\' minimum occurrences validation failed!';
$msg_arr['exception_REST_4001'] = 'REST input parameter \'{param}\' type validation failed!';

$msg_arr['exception_REST_5000'] = 'REST output parameter \'{param}\' minimum occurrences validation failed!';
$msg_arr['exception_REST_5001'] = 'REST output parameter \'{param}\' type validation failed!';

$msg_arr['exception_REST_6000'] = 'REST XML style sheet file could not be loaded!';
$msg_arr['exception_REST_6001'] = 'REST XML style sheet type is not valid!';

?>
