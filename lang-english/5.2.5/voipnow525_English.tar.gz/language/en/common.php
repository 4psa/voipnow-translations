<?php
// English language file - common messages
// Maintained by 4PSA
// docs@4psa.com
// VoipNow 5.2.5

// Modified: $DateTime$
// Revision: $Revision$

    $msg_arr['java_options_max_usr_invalid'] = 'The \'Maximum number of users\' value must be a number.(e.g. 40)';
    $msg_arr['java_options_max_usr_empty'] = 'Please fill in the \'Maximum number of users\' field.';
	$msg_arr['java_options_max_sip_invalid'] = 'The \'Maximum number of phone extensions\' value must be a number.(e.g. 40)';
	$msg_arr['java_options_max_sip_empty'] = 'Please fill in the \'Maximum number of phone extensions\' field.';
	$msg_arr['java_options_max_queue_invalid'] = 'The \'Maximum number of queue extensions\' value must be a number.(e.g. 45)';
	$msg_arr['java_options_max_queue_empty'] = 'Please fill in the \'Maximum number of queue extensions\' field.';
	$msg_arr['java_options_max_ivr_invalid'] = 'The \'Maximum number of IVR extensions\' value must be a number.(e.g. 45)';
	$msg_arr['java_options_max_ivr_empty'] = 'Please fill in the \'Maximum number of IVR extensions\' field.';
	$msg_arr['java_options_max_vcenter_invalid'] = 'The \'Maximum number of voicemail center extensions\' value must be a number.(e.g. 45)';
	$msg_arr['java_options_max_vcenter_empty'] = 'Please fill in the \'Maximum number of voicemail center extensions\' field.';
	$msg_arr['java_options_max_qcenter_invalid'] = 'The \'Maximum number of queue login center extensions\' value must be a number.(e.g. 45)';
	$msg_arr['java_options_max_qcenter_empty'] = 'Please fill in the \'Maximum number of queue login center extensions\' field.';
	$msg_arr['java_options_max_conf_invalid'] = 'The \'Maximum number of conference extensions\' value must be a number.(e.g. 45)';
	$msg_arr['java_options_max_conf_empty'] = 'Please fill in the \'Maximum number of conference extensions\' field.';
	$msg_arr['java_options_max_callback_invalid'] = 'The \'Maximum number of callback extensions\' value must be a number.(e.g. 45)';
	$msg_arr['java_options_max_callback_empty'] = 'Please fill in the \'Maximum number of callback extensions\' field.';
	$msg_arr['java_options_max_callbackcallid_invalid'] = 'The \'Maximum number of callback callerIDs\' value must be a number.(e.g. 45)';
	$msg_arr['java_options_max_callbackcallid_empty'] = 'Please fill in the \'Maximum number of callback callerIDs\' field.';
	$msg_arr['java_options_max_callcardcode_invalid'] = 'The \'Maximum number of calling card codes\' value must be a number.(e.g. 45)';
	$msg_arr['java_options_max_callcardcode_empty'] = 'Please fill in the \'Maximum number of calling card codes\' field.';
	$msg_arr['java_options_max_callcard_invalid'] = 'The \'Maximum number of calling card extensions\' value must be a number.(e.g. 45)';
	$msg_arr['java_options_max_callcard_empty'] = 'Please fill in the \'Maximum number of calling card extensions\' field.';
	$msg_arr['java_options_max_intercom_invalid'] = 'The \'Maximum number of intercom/paging extensions\' value must be a number.(e.g. 45)';
	$msg_arr['java_options_max_intercom_empty'] = 'Please fill in the \'Maximum number of intercom/paging extensions\' field.';
	$msg_arr['java_options_max_qmember_invalid'] = 'The \'Maximum number of queue members\' value must be a number.(e.g. 45)';
	$msg_arr['java_options_max_qmember_empty'] = 'Please fill in the \'Maximum number of queue members\' field.';
	$msg_arr['java_options_max_concurent_invalid'] = 'The \'Maximum public concurrent calls \' value must be a number.(e.g. 40)';
	$msg_arr['java_options_max_concurent_empty'] = 'Please fill in the \'Maximum public concurrent calls\' field.';
	$msg_arr['java_options_max_concurentint_invalid'] = 'The \'Maximum internal concurrent calls \' value must be a number.(e.g. 40)';
	$msg_arr['java_options_max_concurentint_empty'] = 'Please fill in the \'Maximum internal concurrent calls\' field.';
	$msg_arr['java_options_max_text2speach_invalid'] = 'The \'Maximum concurrent text to speech\' value must be a number.(e.g. 40)';
	$msg_arr['java_options_max_text2speach_empty'] = 'Please fill in the \'Maximum concurrent text to speech\' field.';
	$msg_arr['java_options_max_mbox_invalid'] = 'The \'Maximum number of mailboxes\' value must be a number.(e.g. 35)';
	$msg_arr['java_options_max_mbox_empty'] = 'Please fill in the \'Maximum number of mailboxes\' field.';
	$msg_arr['java_options_max_storage_invalid'] = 'The \'Maximum size for storage\' value must be a number.(e.g. 500)';
	$msg_arr['java_options_max_storage_empty'] = 'Please fill in the \'Maximum size for storage\' field.';
	$msg_arr['java_options_acc_expire_invalid'] = 'The \'Account expiration date value\' must be in yyyy-mm-dd format and smaller than 2038-01-01. It cannot exceed parent account expiration date.';
    $msg_arr['java_options_acc_expire_exceeded'] = 'The \'Account expiration date value\' exceeded the parent expire limit.';
	$msg_arr['java_max_sip_less'] = 'The \'Maximum number of phone extensions\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_queue_less'] = 'The \'Maximum number of queue extensions\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_ivr_less'] = 'The \'Maximum number of IVR extensions\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_vcenter_less'] = 'The \'Maximum number of voicemail center extensions\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_qcenter_less'] = 'The \'Maximum number of queue login center extensions\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_conf_less'] = 'The \'Maximum number of conference extensions\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_callback_less'] = 'The \'Maximum number of callback extensions\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_callbackcallid_less'] = 'The \'Maximum number of callback callerIDs\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_callcardcode_less'] = 'The \'Maximum number of calling card codes\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_callcard_less'] = 'The \'Maximum number of calling card extensions\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_intercom_less'] = 'The \'Maximum number of intercom/paging extensions\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_qmember_less'] = 'The \'Maximum number of queue members\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_concurent_less'] = 'The \'Maximum public concurrent calls\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_concurentint_less'] = 'The \'Maximum internal concurrent calls\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_text2speach_less'] = 'The \'Maximum concurrent text to speech\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_mbox_less'] = 'The \'Maximum number of mailboxes\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_storage_less'] = 'The \'Maximum size of storage\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_sip_most'] = 'The value of the \'Maximum number of phone extensions\' field must be at most {value}.';
	$msg_arr['java_max_queue_most'] = 'The value of the \'Maximum number of queue extensions\' field must be at most {value}.';
	$msg_arr['java_max_ivr_most'] = 'The value of the \'Maximum number of IVR extensions\' field must be at most {value}.';
	$msg_arr['java_max_vcenter_most'] = 'The value of the \'Maximum number of voicemail center extensions\' field must be at most {value}.';
	$msg_arr['java_max_qcenter_most'] = 'The value of the \'Maximum number of queue login center extensions\' field must be at most {value}.';
	$msg_arr['java_max_conf_most'] = 'The value of the \'Maximum number of conference extensions\' field must be at most {value}.';
	$msg_arr['java_max_callback_most'] = 'The value of the \'Maximum number of callback extensions\' field must be at most {value}.';
	$msg_arr['java_max_callbackcallid_most'] = 'The value of the \'Maximum number of callback callerIDs\' field must be at most {value}.';
	$msg_arr['java_max_callcardcode_most'] = 'The value of the \'Maximum number of calling card codes\' field must be at most {value}.';
	$msg_arr['java_max_callcard_most'] = 'The value of the \'Maximum number of calling card extensions\' field must be at most {value}.';
	$msg_arr['java_max_intercom_most'] = 'The value of the \'Maximum number of intercom/paging extensions\' field must be at most {value}.';
	$msg_arr['java_max_storage_most'] = 'The value of the \'Maximum size of storage\' field must be at most {value}.';
	$msg_arr['java_max_mbox_most'] = 'The value of the \'Maximum number of mailboxes\' field must be at most {value}.';
	$msg_arr['java_hg_intelligence_requests_most'] = 'The value of the \'Maximum number of monthly intelligence requests\' field must be at most {value}.';
    $msg_arr['java_hg_bot_max_disk_space_used_most'] = 'The value of the \'Maximum disk space used by each bot\' field must be at most {value}.';
	$msg_arr['java_hg_max_file_size_most'] = 'The value of the \'Maximum file size\' field must be at most {value}.';
	$msg_arr['java_hg_max_contacts_most'] = 'The value of the \'Maximum number of contacts\' field must be at most {value}';
    $msg_arr['java_permissions_hg_visitor_inv_limit_most'] = 'The \'Maximum number of Page guest invitations\' field must be at most {value}.';
    $msg_arr['java_permissions_hg_share_pub_limit_most'] = 'The \'Maximum number of public share emails\' field must be at most {value}.';
	$msg_arr['java_hg_max_topic_most'] = 'The value of the \'Maximum number of opened topics for the entire team\' field must be at most {value}';
	$msg_arr['java_hg_message_retention_most'] = 'The value of the \'Maximum number of messages retained per thread\' field must be at most {value}';
    $msg_arr['java_hg_max_bot_most'] = 'The value of the \'Maximum number of bots that can be simultaneously installed per organization\' field must be at most {value}';
    $msg_arr['java_hg_visitor_active_most'] = 'The value of the \'Maximum number of active conversations with Page guests per user\' field must be at most {value}';


	$msg_arr['java_max_qmember_most'] = 'The value of the \'Maximum number of queue members\' field must be at most {value}.';
	$msg_arr['java_max_concurent_most'] = 'The value of the \'Maximum public concurrent calls\' field must be at most {value}.';
	$msg_arr['java_max_concurentint_most'] = 'The value of the \'Maximum internal concurrent calls\' field must be at most {value}.';
	$msg_arr['java_max_text2speach_most'] = 'The value of the \'Maximum concurrent text to speech\' field must be at most {value}.';
	$msg_arr['default'] = 'Default';
 	$msg_arr['internal'] = 'Internal';
	$msg_arr['api_limit_at_most'] = 'Invalid limit {limit}. The value must be at most {min_parent_limit}';
	$msg_arr['callapi_100'] = 'Error connecting to PBX';
	$msg_arr['java_permissions_qalgorithm_invalid'] = 'The \'Computation algorithm\' is invalid';
	$msg_arr['java_permissions_qalgorithm_empty'] = 'Please fill in the \'Computation algorithm\' field';
	$msg_arr['java_permissions_qperuser_invalid'] = 'The \'Quota per user\' value must be a number.(e.g. 40);';
	$msg_arr['java_permissions_qperuser_empty'] = 'Please fill in the \'Quota per user\' field';
	$msg_arr['java_permissions_qperuser_minval'] = 'The \'Quota per user\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_qperuser_most'] = 'The value of the \'Quota per user\' field must be at most {value}';
	$msg_arr['java_permissions_qperorg_invalid'] = 'The \'Quota per organization\' value must be a number.(e.g. 40);';
	$msg_arr['java_permissions_qperorg_empty'] = 'Please fill in the \'Quota per organization\' field';
	$msg_arr['java_permissions_qperorg_minval'] = 'The \'Quota per organization\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_qperorg_most'] = 'The value of the \'Quota per organization\' field must be at most {value}.';
	$msg_arr['java_permissions_qonlyorg_invalid'] = 'The \'Allow quota per user\' is invalid';;
	$msg_arr['java_permissions_qonlyorg_empty'] = 'Please fill in the \'Allow quota per user\' field';

	//Text labels
	$msg_arr['lbl_soap_api_shvmail'] = 'Share Voicemail';
	$msg_arr['lbl_soap_api_shfax'] = 'Share faxes';
	$msg_arr['lbl_soap_api_shrecord'] = 'Share recordings';
	$msg_arr['lnl_soap_api_shcallhist'] = 'Share history';
	$msg_arr['lbl_soap_api_with_value'] = ' set to ';

    // Apply subscription on organization - process statuses
    $msg_arr['apply_sub_succeed'] = 'successful';
    $msg_arr['apply_sub_failed'] = 'unsuccessful';
    $msg_arr['apply_sub_generic_error'] = 'unexpected error';
    $msg_arr['apply_sub_fail_storage'] = 'storage quota could not be updated';
    $msg_arr['apply_sub_fail_user_manag'] = 'user management data could not be updated';
    $msg_arr['apply_sub_fail_user_details'] = 'user details could not be updated';
    $msg_arr['apply_sub_fail_user_billing'] = 'user billing details could not be updated';
    $msg_arr['apply_sub_fail_ext_manag'] = 'user extension management data could not be updated';
    $msg_arr['apply_sub_fail_ext_po'] = 'user extension phone options data could not be updated';
    $msg_arr['apply_sub_fail_org_confext'] = 'organization conference extension could not be created';
    $msg_arr['apply_sub_fail_org_children'] = 'organization children could not be updated ';
