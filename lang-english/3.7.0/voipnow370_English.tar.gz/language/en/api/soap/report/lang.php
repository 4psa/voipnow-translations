<?php

// English language file for SOAP methods
// Maintained by 4PSA
// docs@4psa.com
// VoipNow 3.5.0

// Modified: $DateTime$
// Revision: $Revision$

	//reports 9(5-9)X
	$msg_arr['soap2_err_950'] = 'Invalid month for call costs report.';
	$msg_arr['soap2_err_951'] = 'Invalid year for call costs report.';
	$msg_arr['soap2_err_952'] = 'Invalid start date for call cost report. Mandatory value format: yyyy-mm-dd.';
	$msg_arr['soap2_err_953'] = 'Invalid end date for call cost report. Mandatory value format: yyyy-mm-dd.';
	$msg_arr['soap2_err_954'] = 'Invalid call disposition. Here are the values available: NO ANSWER, ANSWERED, FAILED, BUSY, NOT ALLOWED, UNKNOWN.';
	$msg_arr['soap2_err_955'] = 'Invalid call type. Here are the values available: local, elocal, out.';
	$msg_arr['soap2_err_956'] = 'Invalid call flow. Here are the values available: in, out.';
	$msg_arr['soap2_err_957'] = 'Invalid hangup cause.';
?>