<?php

// English language file for SOAP methods
// Maintained by 4PSA
// docs@4psa.com
// VoipNow 3.0.5

// Modified: $DateTime$
// Revision: $Revision$


	//custom buttons message
	$msg_arr['soap2_err_509'] = 'Unable to update custom buttons with location: {location}. The limit has been exceeded.';

	//time intervals
	$msg_arr['soap2_err_700'] = 'Invalid time interval name. Value must be a string of no more than 255 characters.';
	$msg_arr['soap2_err_701'] = 'Invalid matching algorithm. Here are the values available: day, interval.';
	$msg_arr['soap2_err_702'] = 'Invalid hour value in the \'start at hour\' option. Value must be a number that is bigger than or equal to 0 and smaller than or equal to 23.';
	$msg_arr['soap2_err_703'] = 'Invalid minutes value in the \'start at hour\' option. Value must be a number that is bigger than or equal to 0 and smaller than or equal to 59.';
	$msg_arr['soap2_err_704'] = 'Invalid hour value in the \'end at hour\' option. Value must be a number that is bigger than or equal to 0 and smaller than or equal to 23.';
	$msg_arr['soap2_err_705'] = 'Invalid minutes value in the \'end at hour\' option. Value must be a number that is bigger than or equal to 0 and smaller than or equal to 59.';
	$msg_arr['soap2_err_706'] = 'Invalid start weekday. Accepted values: Monday to Sunday.';
	$msg_arr['soap2_err_707'] = 'Invalid end weekday. Accepted values: Monday to Sunday.';
	$msg_arr['soap2_err_708'] = 'Invalid start date. Accepted values: 1 to 31.';
	$msg_arr['soap2_err_709'] = 'Invalid end date. Accepted values: 1 to 31.';
	$msg_arr['soap2_err_710'] = 'The start hour should precede the end hour when the time interval refers to individual days.';
	$msg_arr['soap2_err_711'] = 'Weekdays should be different when the time interval refers to an interval of days.';
	$msg_arr['soap2_err_712'] = 'The start date must precede the end date.';
	$msg_arr['soap2_err_713'] = 'Invalid month. Value must be numeric, bigger than or equal to 1 and smaller than or equal to 12.';

	//sound files setup
	$msg_arr['soap2_err_718'] = 'Invalid value for \'Music on Hold\' sound filter. Here are the values available: 0- non music on hold sounds, 1- music on hold files, -1- all files.';
	$msg_arr['soap2_err_719'] = 'Invalid value for \'System\' sound filter. Here are the values available: 0: non system sounds, 1 : system sounds,  -1: all files.';
	$msg_arr['soap2_err_720'] = 'The \'Music on hold\' sound folder is not among the folders available for this user.';
	$msg_arr['soap2_err_721'] = 'The \'Thank you\' sound is not within the available sounds list.';
	$msg_arr['soap2_err_722'] = 'The \'Calls waiting\' sound is not within the available sounds list.';
	$msg_arr['soap2_err_723'] = 'The sound played when sending a fax is not within the available sounds list.';
	$msg_arr['soap2_err_724'] = 'The \'All reps busy / wait for next\' sound is not within the available sounds list.';
	$msg_arr['soap2_err_725'] = 'The \'Seconds\' sound is not within the available sounds list.';
	$msg_arr['soap2_err_726'] = 'The \'Minutes\' sound is not within the available sounds list.';
	$msg_arr['soap2_err_727'] = 'The \'Hold time\' sound is not within the available sounds list.';
	$msg_arr['soap2_err_728'] = 'The \'Do not disturb\' sound is not within the available sounds list.';
	$msg_arr['soap2_err_729'] = 'The \'Authentication\' sound is not within the available sounds list.';
	$msg_arr['soap2_err_731'] = 'The \'There are\' sound is not within the available sounds list.';
	$msg_arr['soap2_err_732'] = 'The \'The elapsed queue hold time\' sound is not within the available sounds list.';
	$msg_arr['soap2_err_733'] = 'The \'Welcome\' sound is not within the available sounds list.';
	$msg_arr['soap2_err_734'] = 'The \'Pick-up announcement for agent\' sound is not within the available sounds list.';
	$msg_arr['soap2_err_735'] = 'The \'You are now first in line\' sound is not within the available sounds list.';
	$msg_arr['soap2_err_736'] = 'The sound played on disconnecting is not within the available sounds list.';
	$msg_arr['soap2_err_737'] = 'The sound played when connecting to the conference center is not within the available sounds list.';
	$msg_arr['soap2_err_738'] = 'The sound played when the IVR lifetime expires is not within the available sounds list.';
	$msg_arr['soap2_err_739'] = 'The sound played before connecting to the voicemail center is not within the available sounds list.';

	//sound file setup
	$msg_arr['soap2_err_730'] = 'The \'Record\' sound is not within the available sounds list.';
	$msg_arr['soap2_err_740'] = 'Invalid user level. The available values are the following: serviceProvider, organization, user, extension.';
	$msg_arr['soap2_err_741'] = 'Invalid display method. The available values are: \'inherit\', \'select\'.';
	$msg_arr['soap2_err_742'] = 'Invalid inheritance/display level.';
	$msg_arr['soap2_err_743'] = 'Invalid custom button/alert code. Value must be a string of 3 to 255 characters.';
	$msg_arr['soap2_err_744'] = 'Invalid custom button/alert label. The value must be a string of 3 characters to 255 characters.';
	$msg_arr['soap2_err_745'] = 'Invalid custom button location. Here are the values available: \'navigation\', \'content\'.';
	$msg_arr['soap2_err_746'] = 'Invalid priority. Value must be numeric, bigger than 0 and smaller than 100.';
	$msg_arr['soap2_err_747'] = 'Invalid URL. Please enter a valid URL.';
	$msg_arr['soap2_err_748'] = 'Invalid tool tip. The value must be a string with a minimum of 3 characters and a maximum of 255 characters.';
	$msg_arr['soap2_err_750'] = 'Invalid display level. Possible values: administrator, serviceProvider, organization, user, extension, according to the owner\'s level.';
	$msg_arr['soap2_err_749'] = 'Invalid inheritance level. The value must be a number between 0 and 4, according to the owner\'s level.';
	$msg_arr['soap2_err_751'] = 'Invalid action. The available values are the following: \'new Window\', \'current Window\'.';
	$msg_arr['soap2_err_752'] = 'Invalid custom button/alert expiration date. ';	
?>