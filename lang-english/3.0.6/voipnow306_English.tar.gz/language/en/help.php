<?php
// English Help redirection resource
// Maintained by 4PSA
// docs@4psa.com
// VoipNow 3.0.6

// Modified: $DateTime$
// Revision: $Revision$


$leadinghelp = "http://wiki.4psa.com/plugins/servlet/docs/voipnow300/";
?>