<?php
// English Help redirection resource
// Maintained by 4PSA
// docs@4psa.com
// VoipNow 4.0.0

// Modified: $DateTime$
// Revision: $Revision$


$leadinghelp = "http://wiki.4psa.com/plugins/servlet/docs/voipnow300/";
?>