<?php

// English language file for SOAP methods
// Maintained by 4PSA
// docs@4psa.com
// VoipNow 3.5.0

// Modified: $DateTime$
// Revision: $Revision$

// extension account (general): 350-399
	$msg_arr['soap2_err_350'] = 'Invalid extension type. Here are the values available: term, phoneQueue, ivr, voicecenter, queuecenter, conference, callback, callcard, intercom.';
	$msg_arr['soap2_err_351'] = 'Invalid extension number. Value must be numeric. Field must not be left empty.';
	$msg_arr['soap2_err_352'] = 'Extension number length exceeds PBX settings.';
	$msg_arr['soap2_err_354'] = 'Extension number is in the forbidden extensions list.';
	$msg_arr['soap2_err_355'] = 'Invalid extension type. Extension type {extension_type} does not match extension template.';

	//calling card: 360-399
	$msg_arr['soap2_err_360'] = 'Invalid card code. Value must be 4 to 12 digits long.';
	$msg_arr['soap2_err_361'] = 'Invalid PIN number. Value must be numeric and can oly be 4 to 12 digits long.';
    $msg_arr['soap2_err_362'] = 'Invalid order number. Value cannot have more than 128 characters.';
	$msg_arr['soap2_err_363'] = 'Invalid credit. Value must be a positive float of maximum 15 digits.';

	//callback caller ids
	$msg_arr['soap2_err_366'] = 'Invalid CallerID. Value must be a valid phone number.';
    
	// phone terminal: 400-449
	$msg_arr['soap2_err_400'] = 'The time interval at the end of which the call can be considered without an answer must be a numeric value, bigger than 5 and smaller than 300 (seconds).';
	$msg_arr['soap2_err_401'] = 'The parking timeout must be numeric, bigger than 5 seconds and smaller than 9999 (seconds).';
	$msg_arr['soap2_err_402'] = 'Value for \'Auto delete received faxes older than \' must be a number between 1 and 999.';
    $msg_arr['soap2_err_403'] = 'Value for \'Auto delete recordings older than\' must be a number between 1 and 999.';
	$msg_arr['soap2_err_405'] = 'Invalid password required to connect. The authentication feature enabled requires an authentication name (1 to 5 digits long).';
	$msg_arr['soap2_err_406'] = 'Invalid voicemail auto answer time. Value must be numeric and smaller than the time interval at the end of which the call is considered with no answer.';
	$msg_arr['soap2_err_407'] = 'Invalid conference room size. Value must be numeric, bigger than 2 and smaller than 99.';
	$msg_arr['soap2_err_408'] = 'Invalid fax auto answer time. Value must be numeric, smaller than the time interval at the end of which the call is considered with no answer.';
	$msg_arr['soap2_err_410'] = 'Invalid password to access telephony. Value for \'Password to access telephony\' must be a numeric value of 3 to 12 digits.';
	$msg_arr['soap2_err_413'] = 'Value for \'Auto delete messages older than\' must be a number between 1 and 999.';
	$msg_arr['soap2_err_414'] = 'Invalid CallerID. Check the \'GetAvailableCallerID\' SOAP API function for the CallerIDs available.';
	$msg_arr['soap2_err_415'] = 'Invalid notification method for newly received messages. Here are the values available: message, alert.';
	$msg_arr['soap2_err_416'] = 'Invalid CallerID to set as default. Check the SOAP API function \'Get Available CallerID\' for the CallerIDs available.';
	$msg_arr['soap2_err_419'] = 'Invalid voicemail password. The voicemail feature enabled requires a voicemail password (of 1 to 5 digits).';
	$msg_arr['soap2_err_420'] = 'Invalid notification method for new fax. Here are the values available: fax, alert.';
	$msg_arr['soap2_err_421'] = 'Invalid email address for accepted fax messages.';
	$msg_arr['soap2_err_422'] = 'The virtualization code must be numeric, with mininmum 4 digits and maximum 8 digits.';
	$msg_arr['soap2_err_445'] = 'This extension is not allowed to place outgoing external calls.';
	$msg_arr['soap2_err_448'] = 'Invalid queue login PIN. Value must be numeric and cannot have more than 4 digits.';
	$msg_arr['soap2_err_449'] = 'Invalid CallerID agent.';

	// queue params: 450-480
	$msg_arr['soap2_err_450'] = 'Invalid extension name. The value must be a string of length ranging from 3 to 255 characters.';
	$msg_arr['soap2_err_451'] = 'Invalid timeout (wait time in the queue). The value must be numeric, bigger than the maximum number of rings.';
	$msg_arr['soap2_err_452'] = 'Invalid extension for transferring in case of timeout. The extension must be a phone terminal belonging to the same organization.';
	$msg_arr['soap2_err_453'] = 'Invalid extension for transferring when no calls are allowed to enter queue. The extension must be a phone terminal belonging to the same organization.';
	$msg_arr['soap2_err_454'] = 'Invalid extension for transferring when calls are dropped from queue. The extension must be a phone terminal belonging to the same organization.';
	$msg_arr['soap2_err_455'] = 'Invalid queue size. The value must be numeric, bigger than 1 and smaller than 99 or unlimited.';
	$msg_arr['soap2_err_456'] = 'Invalid waiting period before retrying all agents again. The value must be numeric, bigger than 3 seconds and smaller than 900 seconds.';
	$msg_arr['soap2_err_457'] = 'Invalid service level agreement. The value must be numeric, bigger than 3 seconds and smaller than 9999 (seconds).';
	$msg_arr['soap2_err_458'] = 'Invalid maximum number of rings. The value must be numeric. This field cannot be empty.';
	$msg_arr['soap2_err_459'] = 'Invalid delay period before connecting agent to caller. The value must be numeric, bigger than or equal to 0 and smaller than or equal to 60 (seconds).';
	$msg_arr['soap2_err_460'] = 'Invalid minimum interval between calls. The value must be numeric.';
	$msg_arr['soap2_err_461'] = 'Invalid announce position/estimate hold time period. The value must be numeric. This field cannot be empty.';
	$msg_arr['soap2_err_462'] = 'Invalid periodic announcements frequency. The value must be numeric.';
	$msg_arr['soap2_err_463'] = 'When calls are dropped from queue, the transfer extension should match the transfer extension used when calls are not allowed to enter queue.';
	$msg_arr['soap2_err_464'] = 'Invalid PIN number. The value must be numeric, between 2 and 10 digits long.';
	$msg_arr['soap2_err_465'] = 'Invalid penalty. The value must be numeric, between 0 and 100.';
	$msg_arr['soap2_err_466'] = 'Invalid phone number. The value must be numeric, between 4 and 15 digits long.';
	$msg_arr['soap2_err_467'] = 'Invalid call distribution algorithm. The available values are the following: ring all, least recent, fewest calls, random, memory, linear, wrandom.';
	$msg_arr['soap2_err_468'] = 'Invalid extension to exit on key pressed. The value must contain valid extensions on the same organization.';
	$msg_arr['soap2_err_469'] = 'Invalid queue local agent ID. The value must be a valid phone terminal extension ID.';
	$msg_arr['soap2_err_471'] = 'Invalid remote agent name. Agent name must be between 2 and 255 characters.';
	$msg_arr['soap2_err_472'] = 'Invalid queue local agent ID. The agent is already assigned to this queue.';
	$msg_arr['soap2_err_473'] = 'Invalid interval to reconnect. Please enter a number between 1 and 300 for the connection interval to reconnect the caller to the same agent.';

	// conference extension
	$msg_arr['soap2_err_470'] = 'Invalid trigger for conference recording. Values available: 0-never, 1-always, 2-user\'s choice.';
	
	// ivr extension
	$msg_arr['soap2_err_475'] = 'Invalid trigger for IVR session lifetime expiration. Values available: hangup, transfer, play.';
	$msg_arr['soap2_err_476'] = 'Invalid transfer extension on IVR session lifetime expiration.';
	$msg_arr['soap2_err_477'] = 'Invalid IVR name. Value must be 3 to 32 characters long.';
	$msg_arr['soap2_err_478'] = 'Invalid timeout. Value must be numeric, bigger than 2 and smaller than 60.';
	$msg_arr['soap2_err_479'] = 'Invalid IVR session lifetime. Value must be numeric, bigger than 10 and smaller than 86400.';
	$msg_arr['soap2_err_480'] = 'Invalid IVR clone extension.';

	// incoming call rules
	$msg_arr['soap2_err_481'] = 'Invalid test to apply to completed number. Here are the values available: 0-match, 1-does not match, 2-is anonymous.';
	$msg_arr['soap2_err_482'] = 'Invalid number or telephony regexp. Accepted values: +*XZN.[0-9] characters.';
	$msg_arr['soap2_err_483'] = 'Unable to change incoming call rules. Please provide valid incoming call rule IDs.';
	$msg_arr['soap2_err_486'] = 'Invalid call priority. Value must be numeric, bigger than or equal to 0 and smaller than or equal to 100.';
	$msg_arr['soap2_err_487'] = 'Invalid position. The value must be numeric, with a maximum length of 4 digits, bigger than or equal to 0.';
	$msg_arr['soap2_err_488'] = 'Invalid rule type. Valid rule: {actions}.';
	$msg_arr['soap2_err_484'] = 'Invalid number(s) for call transfer. Please select a valid extension/group or enter a list of external numbers.';
	$msg_arr['soap2_err_485'] = 'Invalid number for call transfer. Value cannot contain more than 30 digits and must follow the phone number format.';
	$msg_arr['soap2_err_490'] = 'Invalid list of IDs in change order request. Sequence must contain the entire incoming call rule IDs of the extension.';
	$msg_arr['soap2_err_491'] = 'Invalid call status. Call status should be set to one of the following: 1 for No Answer, 2 for Rejected, 3 for Busy and 0 for Does not matter.';
	$msg_arr['soap2_err_493'] = 'Invalid ring interval. Accepted values: any number between 5 and 300.';
	$msg_arr['soap2_err_494'] = 'Invalid extension status. Extension status should be set to one of the following: -1 for Not Registered, 1 for Registered, 0 for Does not matter.';
	$msg_arr['soap2_err_495'] = 'Invalid password. Password must be a numeric value of no more than 5 digits.';
	$msg_arr['soap2_err_496'] = 'You are not allowed to provision devices.';

	//Provision errors
	$msg_arr['soap2_err_ext_496'] = 'You are not allowed to use this method to provision the extension. Please use the PBX:EditDevice method.';
	$msg_arr['soap2_err_ext_497'] = 'Invalid sipTransport. Here are the values available: UDP, TCP.';
    $msg_arr['soap2_err_498'] = 'Invalid Media encryption. Here are the values available: None, SDES, DTLS-SRTP.';
    $msg_arr['soap2_err_499'] = 'Invalid DTMF mode. Here are the values available: in band, rfc2833, info, auto.';
?>
