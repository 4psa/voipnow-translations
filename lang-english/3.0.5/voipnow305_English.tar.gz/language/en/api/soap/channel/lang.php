<?php

// English language file for SOAP methods
// Maintained by 4PSA
// docs@4psa.com
// VoipNow 3.0.5

// Modified: $DateTime$
// Revision: $Revision$

	$msg_arr['soap2_err_200'] = 'Duplicate record.{object_detail}';
	$msg_arr['soap2_err_262'] = 'Invalid channel ID.';
	$msg_arr['soap2_err_310'] = 'Provided login is invalid.';
	$msg_arr['soap2_err_313'] = 'Invalid notes. Value cannot contain more than 1024 characters.';

	$msg_arr['soap2_err_chann_314'] = 'Invalid Session refresh interval. Value must be a number between 10 and 84000. (e.g. 3600).';
	$msg_arr['soap2_err_chann_315'] = 'Invalid Minimum session refresh interval. Value must be a number between 90 and 84000.';

	$msg_arr['soap_err_600'] = 'Invalid assignation method. Here are the values available: stacked, exclusive.';
	$msg_arr['soap2_err_600'] = 'Invalid assignation method. Here are the values available: stacked, exclusive.';
	$msg_arr['soap2_err_602'] = 'Invalid DID (Direct Inward Dialing) number. The value must contain only digits and letters.';
	$msg_arr['soap2_err_603'] = 'Invalid monthly cost. Value must be a positive float number of no more than 14 digits.';
	$msg_arr['soap2_err_604'] = 'Invalid incoming call cost definition. Sequence must contain a positive float number of no more than 14 digits and a numeric positive value.';
	$msg_arr['soap2_err_605'] = 'Invalid channel name. Value can only contain 3 to 255 characters.';
	$msg_arr['soap2_err_606'] = 'Invalid hostname/IP address.';
	$msg_arr['soap2_err_607'] = 'Invalid channel password. Value must be at least 1 character long and cannot contain any of the following characters: ;/?:@&=+$,# .';
	$msg_arr['soap2_err_608'] = 'Invalid authorization username.';
	$msg_arr['soap2_err_609'] = 'Invalid concurrent calls (outgoing+incoming) number. Value must be numeric, bigger than 1 and smaller than 999.';
	$msg_arr['soap2_err_610'] = 'Invalid call prefix. Value must follow the phone number format.';
	$msg_arr['soap2_err_611'] = 'Invalid callerID for outgoing calls. Value must be 3 to 255 characters long and must follow the phone number format.';
	$msg_arr['soap2_err_612'] = 'Invalid SIP port. Value must be numeric, between 1 and 65,536.';
	$msg_arr['soap2_err_613'] = 'Invalid proxy host/IP address.';
	$msg_arr['soap2_err_614'] = 'The \'from user\' option is invalid. Value cannot contain more than 255 characters.';
	$msg_arr['soap2_err_615'] = 'Invalid \'from domain\' option.';
	$msg_arr['soap2_err_616'] = 'Invalid authorization extension. Value cannot contain more than 255 characters.';
	$msg_arr['soap2_err_617'] = 'Invalid flow. Here are the values available: in, out, both.';
	$msg_arr['soap2_err_618'] = 'Invalid DTMF mode. Here are the values available: in band, rfc2833, info, auto.';
	$msg_arr['soap2_err_619'] = 'Invalid qualify. Value must be a multiple of 100, no bigger than 900.';
	$msg_arr['soap2_err_620'] = 'One or several provided codecs are outside the available records.';
	$msg_arr['soap2_err_622'] = 'One or several channel groups are outside the available records.';
	$msg_arr['soap2_err_621'] = 'Invalid channel codecs. The codecs list cannot be empty.';
	$msg_arr['soap2_err_623'] = 'One or several public phone numbers are outside the records available.';
	$msg_arr['soap2_err_624'] = 'Invalid channel type. Here are the values available: SIP, IAX, PRI, ENUM.';
	$msg_arr['soap2_err_625'] = 'Invalid DID location.';
	$msg_arr['soap2_err_626'] = 'Invalid session timer. Accepted values: 0 for "Accept", 1 for "Originate", 2 for "Refuse".';
	$msg_arr['soap2_err_627'] = 'Invalid session refresher. Accepted values: 0 for "UAS", 1 for "UAC".';
	$msg_arr['soap2_err_628'] = 'Invalid minimum session refresh interval. Value must be lower than the value provided by the session refresher interval.';
	$msg_arr['soap2_err_629'] = 'Invalid sipTransport. Here are the values available: UDP, TCP.';

	//channel group
	$msg_arr['soap2_err_631'] = 'Invalid channel group name. Value must be 3 to 255 characters long.';
	$msg_arr['soap2_err_632'] = 'One or several channels are outside the available records.';

	//outgoing routing rules

	$msg_arr['soap2_err_641'] = 'Invalid name. Accepted values: letters,_,-,. and space.';
	$msg_arr['soap2_err_642'] = 'Invalid action. Available value: {actions}.';
	$msg_arr['soap2_err_643'] = 'Invalid position. Value cannot contain more than 4 digits and must be bigger than or equal to 0.';
	$msg_arr['soap2_err_644'] = 'Invalid position to insert digits. Value must be a number of no more than 30 digits.';
	$msg_arr['soap2_err_645'] = 'Invalid \'coming from\' option. Value accepted: digits and * .';
	$msg_arr['soap2_err_646'] = 'Invalid number. Value can only contain +*XZN.[0-9] characters and cannot be more than 255 characters long.';
	$msg_arr['soap2_err_647'] = 'Invalid time interval. Value is outside the available records.';
	$msg_arr['soap2_err_648'] = 'Invalid prefix operation. Here are the values: prefix, replace, add, and substract.';
	$msg_arr['soap2_err_649'] = 'Invalid prefix/replace option. Values for prefix or replace cannot contain more than 30 digits and must follow the phone format.';
	$msg_arr['soap2_err_650'] = 'Invalid channel ID. Value is outside the available records.';
	$msg_arr['soap2_err_652'] = 'Invalid number of digits to be deleted. Value must be numeric, smaller than or equal to 30.';
	$msg_arr['soap2_err_653'] = 'Invalid position to insert/delete digits. Value must be numeric, smaller than or equal to 30 and bigger than 0.';
	$msg_arr['soap2_err_654'] = 'Invalid insert number. Value must be a number of no more than 30 digits.';
	$msg_arr['soap2_err_655'] = 'One or several rule IDs are outside the available records.';
	$msg_arr['soap2_err_656'] = 'Invalid portability engine. Please enter an alphanumeric value of no more than 16 characters.';
	$msg_arr['soap2_err_666'] = 'Limit exceeded. Only one outgoing routing rules group can be defined on extension level.';
	$msg_arr['soap2_err_667'] = 'Invalid \'SIP Node\'.';

?>