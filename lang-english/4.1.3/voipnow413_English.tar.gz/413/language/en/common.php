<?php
// English language file - common messages
// Maintained by 4PSA
// docs@4psa.com
// VoipNow 4.1.3

// Modified: $DateTime$
// Revision: $Revision$

	$msg_arr['java_options_max_sip_invalid'] = 'The \'Maximum number of phone extensions\' value must be a number.(e.g. 40)';
	$msg_arr['java_options_max_sip_empty'] = 'Please fill in the \'Maximum number of phone extensions\' field.';
	$msg_arr['java_options_max_queue_invalid'] = 'The \'Maximum number of queue extensions\' value must be a number.(e.g. 45)';
	$msg_arr['java_options_max_queue_empty'] = 'Please fill in the \'Maximum number of queue extensions\' field.';
	$msg_arr['java_options_max_ivr_invalid'] = 'The \'Maximum number of IVR extensions\' value must be a number.(e.g. 45)';
	$msg_arr['java_options_max_ivr_empty'] = 'Please fill in the \'Maximum number of IVR extensions\' field.';
	$msg_arr['java_options_max_vcenter_invalid'] = 'The \'Maximum number of voicemail center extensions\' value must be a number.(e.g. 45)';
	$msg_arr['java_options_max_vcenter_empty'] = 'Please fill in the \'Maximum number of voicemail center extensions\' field.';
	$msg_arr['java_options_max_qcenter_invalid'] = 'The \'Maximum number of queue login center extensions\' value must be a number.(e.g. 45)';
	$msg_arr['java_options_max_qcenter_empty'] = 'Please fill in the \'Maximum number of queue login center extensions\' field.';
	$msg_arr['java_options_max_conf_invalid'] = 'The \'Maximum number of conference extensions\' value must be a number.(e.g. 45)';
	$msg_arr['java_options_max_conf_empty'] = 'Please fill in the \'Maximum number of conference extensions\' field.';
	$msg_arr['java_options_max_callback_invalid'] = 'The \'Maximum number of callback extensions\' value must be a number.(e.g. 45)';
	$msg_arr['java_options_max_callback_empty'] = 'Please fill in the \'Maximum number of callback extensions\' field.';
	$msg_arr['java_options_max_callbackcallid_invalid'] = 'The \'Maximum number of callback callerIDs\' value must be a number.(e.g. 45)';
	$msg_arr['java_options_max_callbackcallid_empty'] = 'Please fill in the \'Maximum number of callback callerIDs\' field.';
	$msg_arr['java_options_max_callcardcode_invalid'] = 'The \'Maximum number of calling card codes\' value must be a number.(e.g. 45)';
	$msg_arr['java_options_max_callcardcode_empty'] = 'Please fill in the \'Maximum number of calling card codes\' field.';
	$msg_arr['java_options_max_callcard_invalid'] = 'The \'Maximum number of calling card extensions\' value must be a number.(e.g. 45)';
	$msg_arr['java_options_max_callcard_empty'] = 'Please fill in the \'Maximum number of calling card extensions\' field.';
	$msg_arr['java_options_max_intercom_invalid'] = 'The \'Maximum number of intercom/paging extensions\' value must be a number.(e.g. 45)';
	$msg_arr['java_options_max_intercom_empty'] = 'Please fill in the \'Maximum number of intercom/paging extensions\' field.';
	$msg_arr['java_options_max_qmember_invalid'] = 'The \'Maximum number of queue members\' value must be a number.(e.g. 45)';
	$msg_arr['java_options_max_qmember_empty'] = 'Please fill in the \'Maximum number of queue members\' field.';
	$msg_arr['java_options_max_concurent_invalid'] = 'The \'Maximum public concurrent calls \' value must be a number.(e.g. 40)';
	$msg_arr['java_options_max_concurent_empty'] = 'Please fill in the \'Maximum public concurrent calls\' field.';
	$msg_arr['java_options_max_concurentint_invalid'] = 'The \'Maximum internal concurrent calls \' value must be a number.(e.g. 40)';
	$msg_arr['java_options_max_concurentint_empty'] = 'Please fill in the \'Maximum internal concurrent calls\' field.';
	$msg_arr['java_options_max_text2speach_invalid'] = 'The \'Maximum concurrent text to speech\' value must be a number.(e.g. 40)';
	$msg_arr['java_options_max_text2speach_empty'] = 'Please fill in the \'Maximum concurrent text to speech\' field.';
	$msg_arr['java_options_max_mbox_invalid'] = 'The \'Maximum number of mailboxes\' value must be a number.(e.g. 35)';
	$msg_arr['java_options_max_mbox_empty'] = 'Please fill in the \'Maximum number of mailboxes\' field.';
	$msg_arr['java_options_max_voice_invalid'] = 'The \'Maximum size for voicemail\' value must be a number.(e.g. 500)';
	$msg_arr['java_options_max_voice_empty'] = 'Please fill in the \'Maximum size for voicemail\' field.';
	$msg_arr['java_options_max_record_invalid'] = 'The \'Maximum disk space for call recording\' value must be a number.(e.g. 500)';
	$msg_arr['java_options_max_record_empty'] = 'Please fill in the \'Maximum disk space for call recording\' field.';
	$msg_arr['java_options_max_sound_invalid'] = 'The \'Maximum disk space for sound files\' value must be a number.(e.g. 500)';
	$msg_arr['java_options_max_sound_empty'] = 'Please fill in the \'Maximum disk space for sound files\' field.';
	$msg_arr['java_options_max_moh_invalid'] = 'The \'Maximum disk space for music on hold files\' value must be a number.(e.g. 500)';
	$msg_arr['java_options_max_moh_empty'] = 'Please fill in the \'Maximum disk space for music on hold files\' field.';
	$msg_arr['java_options_fax_storage_invalid'] = 'The \'Maximum disk space for received faxes\' value must be a number.(e.g. 500)';
	$msg_arr['java_options_fax_storage_empty'] = 'Please fill in the \'Maximum disk space for received faxes\' field.';
	$msg_arr['java_options_acc_expire_invalid'] = 'The \'Account expiration date value\' must be in yyyy-mm-dd format and smaller than 2038-01-01. It cannot exceed parent account expiration date.';
	$msg_arr['java_options_cb_expire_invalid'] = 'The \'Custom button expiration date value \' must be in yyyy-mm-dd format and smaller than 2038-01-01';
	$msg_arr['java_max_sip_less'] = 'The \'Maximum number of phone extensions\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_queue_less'] = 'The \'Maximum number of queue extensions\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_ivr_less'] = 'The \'Maximum number of IVR extensions\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_vcenter_less'] = 'The \'Maximum number of voicemail center extensions\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_qcenter_less'] = 'The \'Maximum number of queue login center extensions\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_conf_less'] = 'The \'Maximum number of conference extensions\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_callback_less'] = 'The \'Maximum number of callback extensions\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_callbackcallid_less'] = 'The \'Maximum number of callback callerIDs\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_callcardcode_less'] = 'The \'Maximum number of calling card codes\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_callcard_less'] = 'The \'Maximum number of calling card extensions\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_intercom_less'] = 'The \'Maximum number of intercom/paging extensions\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_qmember_less'] = 'The \'Maximum number of queue members\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_concurent_less'] = 'The \'Maximum public concurrent calls\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_concurentint_less'] = 'The \'Maximum internal concurrent calls\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_text2speach_less'] = 'The \'Maximum concurrent text to speech\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_mbox_less'] = 'The \'Maximum number of mailboxes\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_voice_less'] = 'The \'Maximum size of voice mailbox\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_record_less'] = 'The \'Maximum disk space for call recording\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_sound_less'] = 'The \'Maximum disk space for sound files\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_moh_less'] = 'The \'Maximum disk space for music on hold files\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_fax_storage_less'] = 'The \'Maximum disk space for received faxes\' value must be a number bigger than or equal to {value}.';
	$msg_arr['java_max_sip_most'] = 'The value of the \'Maximum number of phone extensions\' field must be at most {value}.';
	$msg_arr['java_max_queue_most'] = 'The value of the \'Maximum number of queue extensions\' field must be at most {value}.';
	$msg_arr['java_max_ivr_most'] = 'The value of the \'Maximum number of IVR extensions\' field must be at most {value}.';
	$msg_arr['java_max_vcenter_most'] = 'The value of the \'Maximum number of voicemail center extensions\' field must be at most {value}.';
	$msg_arr['java_max_qcenter_most'] = 'The value of the \'Maximum number of queue login center extensions\' field must be at most {value}.';
	$msg_arr['java_max_conf_most'] = 'The value of the \'Maximum number of conference extensions\' field must be at most {value}.';
	$msg_arr['java_max_callback_most'] = 'The value of the \'Maximum number of callback extensions\' field must be at most {value}.';
	$msg_arr['java_max_callbackcallid_most'] = 'The value of the \'Maximum number of callback callerIDs\' field must be at most {value}.';
	$msg_arr['java_max_callcardcode_most'] = 'The value of the \'Maximum number of calling card codes\' field must be at most {value}.';
	$msg_arr['java_max_callcard_most'] = 'The value of the \'Maximum number of calling card extensions\' field must be at most {value}.';
	$msg_arr['java_max_intercom_most'] = 'The value of the \'Maximum number of intercom/paging extensions\' field must be at most {value}.';
	$msg_arr['java_max_voice_most'] = 'The value of the \'Maximum size of voice mailbox\' field must be at most {value}.';
	$msg_arr['java_max_mbox_most'] = 'The value of the \'Maximum number of mailboxes\' field must be at most {value}.';
	$msg_arr['java_max_qmember_most'] = 'The value of the \'Maximum number of queue members\' field must be at most {value}.';
	$msg_arr['java_max_concurent_most'] = 'The value of the \'Maximum public concurrent calls\' field must be at most {value}.';
	$msg_arr['java_max_concurentint_most'] = 'The value of the \'Maximum internal concurrent calls\' field must be at most {value}.';
	$msg_arr['java_max_text2speach_most'] = 'The value of the \'Maximum concurrent text to speech\' field must be at most {value}.';
	$msg_arr['java_max_record_most'] = 'The value of the \'Maximum disk space for call recording\' field must be at most {value}.';
	$msg_arr['java_max_sound_most'] = 'The value of the \'Maximum disk space for sound files\' field must be at most {value}.';
	$msg_arr['java_max_moh_most'] = 'The value of the \'Maximum disk space for music on hold files\' field must be at most {value}.';
	$msg_arr['java_fax_storage_most'] = 'The value of the \'Maximum disk space for received faxes\' field must be at most {value}.';
	$msg_arr['default'] = 'Default';
 	$msg_arr['internal'] = 'Internal';
	$msg_arr['api_limit_at_most'] = 'Invalid limit {limit}. The value must be at most {min_parent_limit}';
	$msg_arr['callapi_100'] = 'Error connecting to PBX';

	//Text labels
	$msg_arr['lbl_soap_api_shvmail'] = 'Share Voicemail';
	$msg_arr['lbl_soap_api_shfax'] = 'Share faxes';
	$msg_arr['lbl_soap_api_shrecord'] = 'Share recordings';
	$msg_arr['lnl_soap_api_shcallhist'] = 'Share history';
	$msg_arr['lbl_soap_api_with_value'] = ' set to ';
?>