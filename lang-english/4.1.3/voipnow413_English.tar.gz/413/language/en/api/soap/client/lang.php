<?php

// English language file for SOAP methods
// Maintained by 4PSA 
// docs@4psa.com
// VoipNow 4.0.0

// Modified: $DateTime$
// Revision: $Revision$

	$msg_arr['soap2_err_259'] = 'Invalid service provider ID.';
	$msg_arr['soap2_err_900'] = 'The maximum number of terminal extensions for the specified service provider was exceeded.';
	$msg_arr['soap2_err_901'] = 'The maximum number of queue extensions for the specified service provider was exceeded.';
	$msg_arr['soap2_err_902'] = 'The maximum number of conference extensions for the specified service provider was exceeded.';
	$msg_arr['soap2_err_903'] = 'The maximum number of callback extensions for the specified service provider was exceeded.';
	$msg_arr['soap2_err_904'] = 'The maximum number of calling card extensions for the specified service provider was exceeded.';
	$msg_arr['soap2_err_905'] = 'The maximum number of intercom extensions for the specified service provider was exceeded.';
	$msg_arr['soap2_err_906'] = 'The maximum number of IVR back extensions for the specified service provider was exceeded.';
	$msg_arr['soap2_err_907'] = 'The maximum number of voicemail center extensions for the specified service provider was exceeded.';
	$msg_arr['soap2_err_908'] = 'The maximum number of clients for the specified service provider was exceeded.';
	$msg_arr['soap2_err_909'] = 'One of the organizations you want to move owns a queue extension with more agents than the maximum number allowed for the selected service provider.';
	$msg_arr['soap2_err_910'] = 'The organizations you want to move own callback extensions with more callerIDs than the service provider\'s limit allows.';
	$msg_arr['soap2_err_911'] = 'The organizations you want to move own calling card extensions with more codes than the service provider\'s limit allows.';
	$msg_arr['soap2_err_912'] = 'Invalid organization type. Please use one of the following: 0 - Business, 1 - Residential group.';
?>
