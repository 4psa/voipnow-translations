<?php

// English language file for SOAP methods
// Maintained by 4PSA
// docs@4psa.com
// VoipNow 4.0.0


// Modified: $DateTime$
// Revision: $Revision$

	$msg_arr['default_folder'] = 'Default'; // This is the default folder
	$msg_arr['sys_default'] = 'System default';
	
	//Commmon language messages
	$msg_arr['api_invalid_passwd'] = 'The password length must be between 5 and 254 and it must include only letters, digits, -, ., _ and ~ characters';
	$msg_arr['api_weak_passwd'] = 'Please choose a stronger password.';
	$msg_arr['api_invalid_passwd_empty'] = 'This field is mandatory.';
	$msg_arr['api_invalid_user_context'] = 'Invalid user context. ';
	$msg_arr['soap_duplicate_time_interval'] = 'There is another time interval with the same name.';
	$msg_arr['soap_duplicate_out_routing_rule'] = 'There is another outgoing routing rule group with the same name.';
	$msg_arr['soap_duplicate_login'] = 'This login already exists.';
	$msg_arr['soap_duplicate_email'] = 'This email already exists.';
	$msg_arr['soap_duplicate_ext_no'] = 'This extension number already exists.';
	$msg_arr['soap_duplicate_queue_name'] = 'This queue name already exists.';
	$msg_arr['soap_duplicate_ivr_name'] = 'This IVR name already exists.';
	$msg_arr['soap_duplicate_did_no'] = 'This DID number or phone number already exists and cannot be used as a public phone number.';
	$msg_arr['soap_duplicate_channel_name'] = 'This channel name already exists.';
	$msg_arr['soap_duplicate_channel_group'] = 'This channel group name already exists.';
	$msg_arr['soap_duplicate_customb_code'] = 'This custom button/alert code already exists.';
	$msg_arr['soap_duplicate_customb_label'] = 'This custom button/alert label already exists for this client.';
	$msg_arr['soap_duplicate_routekey'] = 'This extension already has one or several routing keys.';
	$msg_arr['soap_duplicate_remote_agent'] = 'This queue already contains a remote agent with this ID.';
	$msg_arr['api_limit_greater_than'] = 'Invalid limit {limit}. Value must be bigger than {max_child_limit}';
	$msg_arr['api_limit_lower_than'] = 'and smaller than {min_parent_limit}.';
	$msg_arr['api_limit_unlimited'] = 'Invalid limit {limit}. Value must be unlimited.';
	$msg_arr['api_allowed_max_storage'] = 'Maximum allowed is {max_limit}.';
	$msg_arr['soap_duplicate_bp_name'] = 'This charging plan name already exists.';
	$msg_arr['soap2_remote_agent_in_queue'] = 'This agent is not a member of the queue. Please use the Assign Queue Remote Agent method to add it to this queue.';
	$msg_arr['soap2_agent_in_queue'] = 'This agent is not in queue. Please use the Assign Queue Agent method.';
	$msg_arr['soap2_area_code'] = "Invalid area code {area_code} definition";
	$msg_arr['soap2_free_minutes_package'] = "Invalid free minutes package definition";

	//notice
	$msg_arr['soap2_notice_003'] = 'The \'Maximum concurrent text to speech\' option is not available unless the PBX preference \'Allow text to speech\' is enabled';
	$msg_arr['soap2_notice_006'] = 'The \'Sound management\' option is not available unless the extension owner has this permission enabled.';
	$msg_arr['soap2_notice_008'] = 'Permission denied to modify user\'s outgoing routing rule group.';
	$msg_arr['soap2_notice_009'] = 'Permission denied to modify user\'s charging plan.';
	$msg_arr['soap2_notice_012'] = 'Permission denied to modify extension type.';
	$msg_arr['soap2_notice_013'] = 'Current incoming money limit/calls credit is unlimited.';
	$msg_arr['soap2_notice_014'] = 'Current outgoing money limit/calls credit is unlimited.';
	$msg_arr['soap2_notice_017'] = 'Permission denied to modify {param}.';
	$msg_arr['soap2_notice_020'] = 'The \'Roles management\' option cannot be disabled if the \'Organizations management\' option or \'Extensions and users management\' option is enabled.';
	$msg_arr['soap2_notice_021'] = 'The \'Extension features management\' option cannot be disabled if the \'Extensions and users management\' option is enabled.';
	$msg_arr['soap2_notice_022'] = 'The \'See stacked phone numbers\' option cannot be enabled if the \'Phone numbers management\' option is disabled.';
	$msg_arr['soap2_notice_024'] = 'Not allowed to set provisioning system IP or hostname.';
	$msg_arr['soap2_notice_025'] = 'One or several incoming call rules could not be updated.';
	$msg_arr['soap2_notice_026'] = 'Incoming money limit/calls credit cannot be set: incoming calls not allowed.';
	$msg_arr['soap2_notice_027'] = 'Outgoing money limit/calls credit cannot be set: outgoing calls not allowed.';
	$msg_arr['soap2_notice_030'] = 'No records.';
	$msg_arr['soap2_notice_031'] = 'Permission denied to modify user\'s template.';
	$msg_arr['soap2_notice_032'] = 'Unable to update incoming call rules status.';
	$msg_arr['soap2_notice_033'] = 'Unable to change incoming call rules order.';
	$msg_arr['soap2_notice_034'] = 'Unable to change incoming call rules.';
	$msg_arr['soap2_notice_035'] = 'Unable to update callerID status.';
	$msg_arr['soap2_notice_036'] = 'Fax to voicemail feature cannot be enabled only unless the voicemail service is enabled.';
	$msg_arr['soap2_notice_037'] = 'Unable to update outgoing routing rules order.';
	$msg_arr['soap2_notice_038'] = 'Unable to update status for one or several outgoing routing rules.';
	$msg_arr['soap2_notice_039'] = 'Unable to update outgoing routing rules group.';
	$msg_arr['soap2_notice_040'] = 'No available upgrades.';
	$msg_arr['soap2_notice_041'] = 'Unable to start upgrade. Another upgrade process has already been initiated.';
	$msg_arr['soap2_notice_042'] = '';
	$msg_arr['soap2_notice_043'] = 'Provisioning disabled on extension.';
	$msg_arr['soap2_notice_044'] = 'Your password is insecure. Please consider choosing a safer one.';
	$msg_arr['soap2_notice_045'] = 'Unable to change incoming call rules keys.';
	$msg_arr['soap2_notice_046'] = 'Authentication key and type cannot be changed for current enrollment server.';
	$msg_arr['soap2_notice_047'] = 'Permission denied. MAC based provisioning is not allowed on HTTP(S).';
	$msg_arr['soap2_notice_048'] = 'MAC based provisioning is allowed only on HTTP(S).';
	$msg_arr['soap2_notice_049'] = '';
	$msg_arr['soap2_notice_050'] = 'Maximum number of parameters allowed to an enrollment master host is {enroll_params}.';
	$msg_arr['soap2_notice_052'] = 'Limit {limit} exceeding upper limitation cast to parent settings.';
	$msg_arr['soap2_notice_051'] = 'This license key strictly allows phone terminal extension management.';
	$msg_arr['soap2_notice_053'] = 'Account already irreversibly suspended.';
	$msg_arr['soap2_notice_054'] = 'One or several area codes are already among cost exceptions.';
	$msg_arr['soap2_notice_055'] = 'Unable to update user phone status.';
	$msg_arr['soap2_notice_056'] = 'Permission denied: this account is irreversibly disabled from {app_name} Automation.';
	$msg_arr['soap2_notice_057'] = 'Permission denied to suspend account from {app_name} Automation.';
	$msg_arr['soap2_notice_058'] = 'Fax storage space limited to the owner\'s quota.';
	$msg_arr['soap2_notice_059'] = 'Record storage space limited to the owner\'s quota.';
	$msg_arr['soap2_notice_060'] = 'Voicemail storage space limited to the owner\'s quota.';
	$msg_arr['soap2_notice_061'] = 'No permission to link account with an external resource.';
	$msg_arr['soap2_notice_062'] = 'The sound played when sending a fax is not within the available sounds list.';
	$msg_arr['soap2_notice_063'] = 'Share policy settings were not updated.';
	$msg_arr['soap2_notice_064'] = 'Sound {sound_id} is disabled. Please choose a different sound to use.';
	$msg_arr['soap2_notice_065'] = 'The following sound is invalid: {sound_id}. Default values, if available, have been used.';
	$msg_arr['soap2_notice_066'] = 'Unable to assign currently used callerIDs.';
	$msg_arr['soap2_notice_067'] = 'Unable to change phone access restriction.';
	$msg_arr['soap2_notice_068'] = 'Unable to update calling card code status.';
	$msg_arr['soap2_notice_069'] = 'Anytime has been used to define one or several \'External outgoing minutes\'.';
	$msg_arr['soap2_notice_076'] = 'Conference settings not updated: extension is not multi-user aware.';
	$msg_arr['soap2_notice_077'] = 'Invalid option used to allow calls to enter queue. Default value has been used instead.';
	$msg_arr['soap2_notice_078'] = 'Option used to drop calls from queue is invalid. Default value has been used instead';
	$msg_arr['soap2_notice_079'] = 'Permission to modify sharing policies denied: extension is not multi user aware.';
	$msg_arr['soap2_notice_081'] = 'You are not allowed to modify the Provision management permission.';
	$msg_arr['soap2_notice_083'] = 'Invalid provisioning management permission. Accepted values: 0 for "None", 2 for "View", 4 for "View".';
	$msg_arr['soap2_notice_084'] = 'To make it available, purchase a higher limit SIP trunking license';
	$msg_arr['soap2_notice_085'] = 'To make it available, setup the "Maximum public concurrent calls" to a limited number';
	$msg_arr['soap2_notice_086'] = 'This callback CallerID code cannot be activated. The commercial limit provided by this license key has been reached.';
	$msg_arr['soap2_notice_087'] = 'This calling card code cannot be activated. The commercial limit provided by this license key has been reached.';
	$msg_arr['soap2_notice_088'] = 'This calling card code {identifier} is not within the list of available codes.';
	$msg_arr['soap2_notice_089'] = 'The \'SIP trunking management\' option cannot be enabled if the \'Phone extension SIP management\' option is disabled.';
	$msg_arr['soap2_notice_090'] = 'Cannot modify permission {permission}. Parent acccount settings do not allow it.';
	
	$msg_arr['soap2_notice_100'] = 'The authentication data for access to this area or the object identification number is invalid.';
	$msg_arr['soap2_notice_200'] = 'Unable to completly assign public phone numbers. Not enough numbers available.';
	$msg_arr['soap2_notice_201'] = 'Some channel groups could not be removed. Please check out if they are not in use.';
	$msg_arr['soap2_notice_202'] = 'Account expire date cast to parent account expire date.';
	
	#license
	$msg_arr['soap2_err_050'] = 'Invalid license key for VoipNow.';
	$msg_arr['soap2_err_051'] = 'This license key strictly allows phone terminal extension management.';
	$msg_arr['soap2_err_053'] = 'The commercial limit provided by this license key has been reached.';
	$msg_arr['soap2_err_054'] = 'The present license does not expose Automation functionality.';
	$msg_arr['soap2_err_055'] = 'This operation is disabled because the installation is violating a licensing limit. Disable SIP trunking support on some extensions, lower the "Maximum public concurrent calls" limit on extensions with SIP trunking enabled or purchase a higher limit license.';
	
	#enrollment
	$msg_arr['soap2_err_090'] = 'Invalid enrollment scope. Value must be a string of 3 to 255 characters.';
	$msg_arr['soap2_err_091'] = 'Invalid master enrollment server IP/URL.';
	$msg_arr['soap2_err_092'] = 'Invalid master enrollment server authentication key. Value must be a string of 2 to 255 characters.';
	$msg_arr['soap2_err_093'] = 'Invalid master enrollment server authentication type. Value must be a string of 2 to 255 characters.';

	# authentication errors: 100-max149
	$msg_arr['soap2_err_100'] = 'The authentication token used to access this area or the object identification number is invalid.';
	$msg_arr['soap2_err_101'] = 'You are not allowed to authenticate to this area.';
	$msg_arr['soap2_err_102'] = 'This account has expired.';
	$msg_arr['soap2_err_103'] = 'Access to this service is denied.';
	$msg_arr['soap2_err_104'] = 'This account has been disabled.';
	$msg_arr['soap2_err_105'] = 'Access to this object is denied.';
	$msg_arr['soap2_err_106'] = 'The authentication token used to access this area is expired.';
	$msg_arr['soap2_err_107'] = 'The authentication token used to access this area has already been used.';
	$msg_arr['soap2_err_108'] = 'The authentication token used to access this area does not allow access to this type of object.';
	$msg_arr['soap2_err_109'] = 'Can not access this area, because extension features management is disabled for this account.';
	$msg_arr['soap2_err_113'] = 'Invalid user context ID. Please check context user level.';
	$msg_arr['soap2_err_115'] = 'Permission denied to add user from this context account.';
	$msg_arr['soap2_err_117'] = 'Request invalid. Missing parameter {param}.';

	# internal errors: 150-199
	$msg_arr['soap2_err_150'] = 'Authentication failed due to an internal error: please try again later.';
	$msg_arr['soap2_err_151'] = 'Unable to retrieve the set of information.';
	$msg_arr['soap2_err_152'] = 'Unable to update the set of information.';
	$msg_arr['soap2_err_153'] = 'Unable to find endpoint request handler.';
	$msg_arr['soap2_err_156'] = 'Unable to set provisioning system IP/hostname and PBX system IP/hostname.';
	$msg_arr['soap2_err_157'] = 'Unable to generate the phone terminal provisioning file.';
	$msg_arr['soap2_err_158'] = 'Unable to initiate CallAPI request.';
	$msg_arr['soap2_err_160'] = 'Function \'{method}\' no longer supported.';

	# duplicate record error: 200-249
	$msg_arr['soap2_err_200'] = 'Duplicate record.{object_detail}'; //bp
	$msg_arr['soap2_err_201'] = 'No extension setup preferences for this extension type.'; //bp
	$msg_arr['soap2_err_202'] = 'Duplicate email address.{object_detail}'; //bp

	# object id errors : 250-300
	$msg_arr['soap2_err_250'] = 'Invalid user ID.';
	$msg_arr['soap2_err_251'] = 'Invalid parent ID.';
	$msg_arr['soap2_err_252'] = 'Invalid template ID.';
	$msg_arr['soap2_err_253'] = 'Invalid calling card code ID.';
	$msg_arr['soap2_err_254'] = 'Invalid CallerID record ID.';
	$msg_arr['soap2_err_255'] = 'Invalid parent login.';
	$msg_arr['soap2_err_256'] = 'Invalid sound language ID.';
	$msg_arr['soap2_err_257'] = 'Invalid free minutes package ID.';
	$msg_arr['soap2_err_258'] = 'Invalid charging plan ID.';
	$msg_arr['soap2_err_260'] = 'Invalid outgoing routing rules group ID.';
	$msg_arr['soap2_err_261'] = 'Invalid sound file ID.'; // restrict call sound for charging plan
	$msg_arr['soap2_err_262'] = 'Invalid channel ID.';
	$msg_arr['soap2_err_263'] = 'Invalid public phone number ID.';
	$msg_arr['soap2_err_264'] = 'Invalid channel group ID.';
	$msg_arr['soap2_err_265'] = 'Invalid user login.';
	$msg_arr['soap2_err_266'] = 'Invalid time interval block ID.';
	$msg_arr['soap2_err_268'] = 'Invalid queue ID.';
	$msg_arr['soap2_err_269'] = 'Invalid time interval ID.';
	$msg_arr['soap2_err_270'] = 'Invalid custom button/alert code.';
	$msg_arr['soap2_err_271'] = 'Invalid charging plan identifier.';
	$msg_arr['soap2_err_274'] = 'Invalid agent ID.';
    $msg_arr['soap2_err_275'] = 'Invalid transfer extension number.';

	/* add/update account errors */
	$msg_arr['soap2_err_300'] = 'Invalid email address.';
	$msg_arr['soap2_err_301'] = 'Invalid country code.';
	$msg_arr['soap2_err_302'] = '{invalid_password}';
	//$msg_arr['soap2_err_303'] = 'Invalid state/province.';
	$msg_arr['soap2_err_303'] = 'Invalid charging idenfier. Value must be an alphanumeric (exception: \'_\', \'-\', \'*\') string of 6 to 32.';
	$msg_arr['soap2_err_304'] = 'Invalid phone number. Value must follow the phone number format.';
	$msg_arr['soap2_err_305'] = 'Invalid fax number. Value must follow the phone number format.';
	$msg_arr['soap2_err_306'] = 'Invalid language code. Check the PBX functions available for the language codes available.';
	$msg_arr['soap2_err_307'] = 'Invalid name. Value must have be a string of 1 to 255 characters.';
	$msg_arr['soap2_err_308'] = 'Invalid company name. Value must be a string of 3 to 255 characters.';
	$msg_arr['soap2_err_309'] = 'Invalid address. Name must have at least 3 characters, but no more than 255 characters.';
	$msg_arr['soap2_err_310'] = 'Invalid login provided.';
	$msg_arr['soap2_err_311'] = 'Invalid city. Value must contain at least 2 characters, but no more than 255 characters.';
	$msg_arr['soap2_err_312'] = 'Invalid postal/zip code.';
	$msg_arr['soap2_err_313'] = 'Invalid notes. Value cannot contain more than 1024 characters.';
	$msg_arr['soap2_err_314'] = 'Invalid region. Please use PBX:GetRegions for the list of available regions.';
	$msg_arr['soap2_err_315'] = 'Invalid charging plan. This charging plan does not belong to the charging plans of the user\'s owner.';
	$msg_arr['soap2_err_316'] = 'Invalid billing server identifier.';
	$msg_arr['soap2_err_317'] = 'Invalid billing server IP or hostname. Value must be an IPV4 IP address or a valid hostname.';
	$msg_arr['soap2_err_318'] = 'Invalid enrollment server scope. Value must contain at least 2 characters, but no more than 255 characters.';
	$msg_arr['soap2_err_319'] = 'Invalid timezone. Please use PBX:GetTimezone for the list of available regions.';
	$msg_arr['soap2_err_320'] = 'Invalid user phone status. Possible values: {phone_status}';
	$msg_arr['soap2_err_321'] = 'Account is already linked to an external resource.';
	$msg_arr['soap2_err_322'] = 'Resource identifier for remote account linkage is invalid.';
	$msg_arr['soap2_err_323'] = '{weak_password}';
    $msg_arr['soap2_err_324'] = 'Invalid Service Provider name. Value must be a string of 3 to 255 characters.';
	$msg_arr['soap2_err_325'] = 'Invalid user role';
    $msg_arr['soap2_err_326'] = 'Invalid otherNotifyEmail parameter.';

	//
	$msg_arr['soap2_err_780'] = 'Invalid URL. Please enter a valid URL.';
	$msg_arr['soap2_err_843'] = 'Invalid country code.';
	$msg_arr['api_phonestatus_full'] = '1 - Customer phone is fully enabled.';
	$msg_arr['api_phonestatus_callin'] = '16 - Customer can be called and can call internally.';
	$msg_arr['api_phonestatus_calledonly'] = '32 - Only customer can be called.';
	$msg_arr['api_phonestatus_disabled'] = '64 - Customer cannot use phone service';
	$msg_arr['soap2_err_528'] = "Permission denied: this account is irreversibly disabled from {app_name} Automation.";
	$msg_arr['soap2_err_601'] = 'Invalid public phone number. Value must follow the phone number format. This field is mandatory.';

	//Text labels
	$msg_arr['lbl_soap_api_shvmail'] = 'Share Voicemail';
	$msg_arr['lbl_soap_api_shfax'] = 'Share faxes';
	$msg_arr['lbl_soap_api_shrecord'] = 'Share recordings';
	$msg_arr['lbl_soap_api_shcallhist'] = 'Share history';

	$msg_arr['lbl_in_rule_action_auth'] = 'Authenticate';
	$msg_arr['lbl_in_rule_action_setcalprio'] = 'Set call priority';
	$msg_arr['lbl_in_rule_action_transfer'] = 'Transfer';
	$msg_arr['lbl_in_rule_action_cascade'] = 'Cascade';
	$msg_arr['lbl_in_rule_action_busy'] = 'Play Busy';
	$msg_arr['lbl_in_rule_action_congestion'] = 'Play Congestion';
	$msg_arr['lbl_in_rule_action_hangup'] = 'Hangup';

	// extension account (general): 350-399
	// permissions and limits setup
	$msg_arr['soap2_err_500'] = 'Invalid queue members limit. Maximum number of queue members must be bigger than the number of currently set agents.';
	$msg_arr['soap2_err_501'] = 'Invalid calling card codes limit. Maximum number of calling card codes must be bigger than the number of currently set codes.';
	$msg_arr['soap2_err_502'] = 'Invalid account expire time. Value can be any date between 1970 and 2038 or unlimited.';
	$msg_arr['soap2_err_504'] = 'Invalid callback callerIDs limit. Maximum number of callback CallerIDs must be bigger than the number of currently set callerIDs.';
	$msg_arr['soap2_err_503'] = 'Invalid concurent internal calls limit. Value must be integer.';

	//limits
	// storage space
	$msg_arr['soap2_err_505'] = '{parent_limitations}';
	$msg_arr['soap2_err_506'] = 'Invalid record storage space. The value exceeds the owner\'s quota.';
	$msg_arr['soap2_err_507'] = 'Invalid voicemail storage space. The value exceeds the owner\'s quota.';
	$msg_arr['soap2_err_508'] = 'Invalid fax storage space. The value exceeds the owner\'s quota.';
	$msg_arr['soap2_err_513'] = 'Unable to add more extensions of the required type. The limit has been exceeded.';
	$msg_arr['soap2_err_514'] = 'Unable to add more users. The limit has been exceeded.';

	//permissions
	$msg_arr['soap2_err_515'] = 'Permission denied: the extensions and users management setting is disabled.';
	$msg_arr['soap2_err_516'] = 'Permission denied: the organizations management setting is disabled.';
	$msg_arr['soap2_err_517'] = 'Permission denied: illegal operation was performed on accounts setup by VoipNow Automation.';
	$msg_arr['soap2_err_520'] = 'Permission denied: the charging plan management setting is disabled.';
	$msg_arr['soap2_err_521'] = 'Permission denied: the extension is not multi-user aware.';
	$msg_arr['soap2_err_525'] = 'Permission denied: the roles and phone numbers setting is disabled.';
	$msg_arr['soap2_err_526'] = 'Permission denied: the phone number management setting is disabled.';
	$msg_arr['soap2_err_527'] = "Permission denied: the limit of records has been reached.";
	$msg_arr['soap2_err_530'] = "Permission denied: invalid group(s) assigned for '{shperm}' policy.";
	$msg_arr['soap2_err_531'] = "Permission denied: you are not allowed to activate {param}.";
	$msg_arr['soap2_err_532'] = "Permission denied: maximum number of queue members has been reached.";
    $msg_arr['soap2_err_533'] = 'Permission denied: the extension to transfer to is not multi-user aware.';
    $msg_arr['soap2_err_534'] = 'Permission denied: the extension to transfer to is not under the same organization.';
	$msg_arr['soap2_err_620'] = 'One or several provided codecs are outside the available records.';

	//provisioning 8(5-9)x
	$msg_arr['soap2_err_850'] = 'Invalid password. Value must contain at least 5 characters and follow the password format.';
	$msg_arr['soap2_err_851'] = 'Invalid phone brand and model. Check the SystemAPI function GetEquipmentList for available records.';
	$msg_arr['soap2_err_852'] = 'Invalid firmware.';
	$msg_arr['soap2_err_853'] = 'Invalid phone MAC. Value must be a valid MAC address in format 00:00:00:00:00:00.';
	$msg_arr['soap2_err_854'] = 'Invalid equipment description. Value must be a string of no more than 255 characters.';
	$msg_arr['soap2_err_855'] = 'Invalid phone admin username.';
	$msg_arr['soap2_err_856'] = 'Invalid phone admin password.';
	$msg_arr['soap2_err_857'] = 'Invalid phone update interval. Value must be numeric, bigger than or equal to 1 and smaller than or equal to 999.';
	$msg_arr['soap2_err_858'] = 'Invalid provisioning system IP or hostname. Value must be an IPv4 IP Address or a valid hostname.';
	$msg_arr['soap2_err_859'] = 'Invalid PBX system IP or hostname. Value must be an IPv4 IP Address or a valid hostname.';
	$msg_arr['soap2_err_860'] = 'Invalid protocol.';
	$msg_arr['soap2_err_861'] = 'Invalid \'Phone does not register and is located on IP\'. Value must be a valid IP address.';
	$msg_arr['soap2_err_862'] = 'Invalid port. Value must be numeric, bigger than or equal to 0 and smaller than or equal to 65535.';
	$msg_arr['soap2_err_863'] = 'The phone port cannot be empty if the phone is bound to a certain IP.';
    $msg_arr['soap2_err_864'] = 'Invalid IP for the extension to register on.';
	$msg_arr['soap2_err_925'] = 'Authentication key for enrollment server with scope {scope} cannot be changed.';	
	$msg_arr['soap2_err_common_864'] = 'Invalid provisioning template.';
	$msg_arr['soap2_err_common_865'] = 'Invalid provisioning friendly name.';
	$msg_arr['soap2_err_common_866'] = 'Invalid provisioning status.';
	$msg_arr['soap2_err_common_867'] = 'Invalid provisioning serial.';
	$msg_arr['soap2_err_common_868'] = 'Permission denied: you are not allowed to see devices of the user provided by the UserID (UserIdentifier) parameter.';
	$msg_arr['soap2_err_common_869'] = 'Permission denied: you are not allowed to see devices.';
	$msg_arr['soap2_err_common_870'] = 'Invalid serial. This serial already exists.';
	$msg_arr['soap2_err_common_871'] = 'Invalid client to assign device to.';
	$msg_arr['soap2_err_common_872'] = 'Invalid line number associated to an extension.';
	$msg_arr['soap2_err_common_873'] = 'Invalid or missing connection IP';
	$msg_arr['soap2_err_common_874'] = 'Invalid or missing mask';
	$msg_arr['soap2_err_common_875'] = 'Invalid or missing gateway';
	$msg_arr['soap2_err_common_876'] = 'Invalid MAC address. The MAC address is already in the system.';
	$msg_arr['soap2_err_common_877'] = 'Invalid client assigned to this device. The client must belong to the owner of the device.';
	$msg_arr['soap2_err_common_878'] = 'One or several extensions assigned to the device are invalid.';
	$msg_arr['soap2_err_common_879'] = 'Invalid or missing MAC address.';
	$msg_arr['soap2_err_common_880'] = 'Assigned extensions are missing or invalid.';
	$msg_arr['soap2_err_common_881'] = 'Invalid or missing connection setup parameters';
	$msg_arr['soap2_err_common_882'] = 'Invalid \'Allow extension SIP connection only from IP \'.';
	$msg_arr['soap2_err_common_883'] = 'Invalid \'Firmware Version\'. Value must be an alphanumeric string and cannot contain characters other than -';
	$msg_arr['soap2_err_common_884'] = 'Invalid \'Timezone ID\'. Check the System API function GetTimezones for the records available.';
	$msg_arr['soap2_err_common_885'] = 'Invalid device ID.';
	$msg_arr['soap2_err_common_886'] = 'Permission denied: you are not allowed to add devices for the given extension.';