<?php
	$msg_arr['soap2_err_950'] = 'Reporte de los costes de las llamadas del mes incorrecto.';
	$msg_arr['soap2_err_951'] = 'Reporte de los costes de las llamadas del año incorrecta.';
	$msg_arr['soap2_err_952'] = 'Fecha de inicio incorrecto para los informes de costes de llamadas. El valor debe ser en formato: yyyy-mm-dd.';
	$msg_arr['soap2_err_953'] = 'Fecha final para el reporte de costes de llamadas. El valor debe ser en formato: yyyy-mm-dd.';
	$msg_arr['soap2_err_954'] = 'Invalid call disposition. The available values are: NO ANSWER, ANSWERED, FAILED, BUSY, NOT ALLOWED, UNKNOWN.';
	$msg_arr['soap2_err_955'] = 'Invalid call type. The available values are: local, elocal, out.';
	$msg_arr['soap2_err_956'] = 'Invalid call flow. The available values are: in, out.';
	$msg_arr['soap2_err_957'] = 'Invalid hangup cause.';
?>