<?php
	$msg_arr['soap2_err_259'] = 'ID de proveedor de servicio no válido.';
	$msg_arr['soap2_err_900'] = 'Se ha superado el número máximo de extensiones de terminales para el proveedor especificado.';
	$msg_arr['soap2_err_901'] = 'Se ha superado el número máximo de extensiones de la cola para el proveedor especificado.';
	$msg_arr['soap2_err_902'] = 'Se ha superado el número máximo de extensiones de la Conferencia para el proveedor especificado.';
	$msg_arr['soap2_err_903'] = 'Se ha superado el número máximo de extensiones de devolución de llamada para el proveedor especificado.';
	$msg_arr['soap2_err_904'] = 'Se ha superado el número máximo de extensiones de tarjeta de llamada para el proveedor especificado.';
	$msg_arr['soap2_err_905'] = 'Se ha superado el número máximo de extensiones de intercomunicación para el proveedor especificado.';
	$msg_arr['soap2_err_906'] = 'Se ha superado el número máximo de extensiones posteriores de IVR para el proveedor especificado.';
	$msg_arr['soap2_err_907'] = 'Se ha superado el número máximo de extensiones de centro de correo de voz para el proveedor especificado.';
	$msg_arr['soap2_err_908'] = 'Se ha superado el número máximo de clientes para el proveedor especificado.';
	$msg_arr['soap2_err_909'] = 'Una de las organizaciones que desea mover posee una extensión de cola con agentes mayor que el número máximo permitido para el proveedor de servicio seleccionado.';
	$msg_arr['soap2_err_910'] = 'Las organizaciones que desea mover posee extensiones de devolución de llamada con callerIDs mayores que el límite que permite el proveedor\\es del servicio.';
	$msg_arr['soap2_err_911'] = 'Las organizaciones que desee mover posee extensiones de la propia tarjeta de llamada con más códigos de los que permite el límite del proveedor\\es de servicio.';
	$msg_arr['soap2_err_912'] = 'Tipo de organización no válido. Por favor utilice uno de los siguientes: 0 - negocios, 1 - grupo residencial.';
?>