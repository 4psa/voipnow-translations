<?php
	$msg_arr['exception_REST_1000'] = 'REST serverio tikrinimo schema, negali būti pakraunama!!';
	$msg_arr['exception_REST_2000'] = 'REST užkalusa handler klasės nerasta!';
	$msg_arr['exception_REST_2001'] = 'REST užkalusa handler funkcijos nerasta!';
	$msg_arr['exception_REST_2002'] = 'REST užkalusa handler funkcijos nerasta!';
	$msg_arr['exception_REST_2003'] = 'Both funkcija ir klasė REST užkalusa handlers nerasta šiai užkalusai!';
	$msg_arr['exception_REST_2004'] = 'REST užkalusa initiator authentication handler class nerasta!';
	$msg_arr['exception_REST_3000'] = 'REST užkalusa method nerasta!';
	$msg_arr['exception_REST_4000'] = 'REST įvedimo  parameterai \'{param}\' minimumas occurrences nepraejo patikrinimo!';
	$msg_arr['exception_REST_4001'] = 'REST įvedimo  parameterai \'{param}\' tipas nepraejo patikrinimo!';
	$msg_arr['exception_REST_5000'] = 'REST išvesties parameteras \'{param}\' minimumo occurrences nepraejo patikrinimo!';
	$msg_arr['exception_REST_5001'] = 'REST išvesties parameteras \'{param}\' tipas nepraejo patikrinimo!';
	$msg_arr['exception_REST_6000'] = 'REST XML stiliaus lapo failas negali buti pakrautas!';
	$msg_arr['exception_REST_6001'] = 'REST XML stiliaus lapo tipas neteisingas!';
?>