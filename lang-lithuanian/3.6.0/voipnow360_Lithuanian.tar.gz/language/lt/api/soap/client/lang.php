<?php
	$msg_arr['soap2_err_259'] = 'Neteisingas Patintojo ID.';
	$msg_arr['soap2_err_900'] = 'Maksimalus skaičius platintojo telefono išplėtimų pasiektas .';
	$msg_arr['soap2_err_901'] = 'Maksimalus skaičius platintojo eilių pasiektas.';
	$msg_arr['soap2_err_902'] = 'Maksimalus skaičius platintojo confercijų išplėtimų pasiektas.';
	$msg_arr['soap2_err_903'] = 'Maksimalus skaičius platintojo  callback išplėtimų pasiektas.';
	$msg_arr['soap2_err_904'] = 'Maksimalus skaičius platintojo calling card išplėtimų pasiektas.';
	$msg_arr['soap2_err_905'] = 'Maksimalus skaičius platintojo intercom išplėtimų pasiektas.';
	$msg_arr['soap2_err_906'] = 'Maksimalus skaičius platintojo IVR back extensions išplėtimų pasiektas.';
	$msg_arr['soap2_err_907'] = 'Maksimalus skaičius platintojovoicemail center išplėtimų pasiektas.';
	$msg_arr['soap2_err_908'] = 'Maksimalus skaičius platintojo clients išplėtimų pasiektas.';
	$msg_arr['soap2_err_909'] = 'Vienas iš klientų nori pertemti eiles negalimas.';
	$msg_arr['soap2_err_910'] = 'Klientai nori pertempti  callback išplėtimų negalimas.';
	$msg_arr['soap2_err_911'] = 'Klientai nori pertempticalling card išplėtimų  negalimas.';
	$msg_arr['soap2_err_912'] = 'Neteisingas organizacijos tippas. Prašome naudoti: 0 - Business, 1 - Residential group.';
?>