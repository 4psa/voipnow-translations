<?php
	$msg_arr['soap2_err_950'] = 'Neteisingas mėnesio skambučių išlaidas ataskaita.';
	$msg_arr['soap2_err_951'] = 'Neteisingas metai skambučių išlaidas ataskaita..';
	$msg_arr['soap2_err_952'] = 'Neteisingas pradžios data skambučių sąnaudų ataskaitos.Vertė turi būti formatu: yyyy-mm-dd.';
	$msg_arr['soap2_err_953'] = 'Neteisingas pabaigos data skambučių išlaidų ataskaitą.Vertė turi būti formatu: yyyy-mm-dd.';
	$msg_arr['soap2_err_954'] = 'Neteisingas skambutis dispozicija. Galimos reikšmės yra: jokio atsakymo, atsakė nepavyko, užimtas, DRAUDŽIAMA, nežinoma.';
	$msg_arr['soap2_err_955'] = 'Neteisingas skambučių srautas. Galimos reikšmės yra: out';
	$msg_arr['soap2_err_956'] = 'Neteisingas ryšio rūšis. Galimos reikšmės yra: vietos, elocal išejimas.';
	$msg_arr['soap2_err_957'] = 'Neteisingas Atjungimo priežastis.';
?>