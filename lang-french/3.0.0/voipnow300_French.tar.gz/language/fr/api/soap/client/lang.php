<?php
	$msg_arr['soap2_err_259'] = 'ID de fournisseur de service invalide.';
	$msg_arr['soap2_err_900'] = 'Le nombre maximal d\'extensions de terminal pour le fournisseur de service spécifié a été dépassé.';
	$msg_arr['soap2_err_901'] = 'Le nombre maximal d\'extensions de queue pour le fournisseur de service spécifié a été dépassé.';
	$msg_arr['soap2_err_902'] = 'Le nombre maximal d\'extensions de conférence pour le fournisseur de service spécifié a été dépassé.';
	$msg_arr['soap2_err_903'] = 'Le nombre maximal d\'extensions de callback pour le fournisseur de service spécifié a été dépassé.';
	$msg_arr['soap2_err_904'] = 'Le nombre maximal d\'extensions de carte d\'appel pour le fournisseur de service spécifié a été dépassé.';
	$msg_arr['soap2_err_905'] = 'Le nombre maximal d\'extensions d\'interphone pour le fournisseur de service spécifié a été dépassé.';
	$msg_arr['soap2_err_906'] = 'Le nombre maximal d\'extensions d\'IVR pour le fournisseur de service spécifié a été dépassé.';
	$msg_arr['soap2_err_907'] = 'Le nombre maximal d\'extensions de centre de messagerie vocale pour le fournisseur de service spécifié a été dépassé.';
	$msg_arr['soap2_err_908'] = 'Le nombre maximal de clients pour le fournisseur de service spécifié a été dépassé.';
	$msg_arr['soap2_err_909'] = 'Une des organisations que vous désirez déplacer possède une extension de queue avec plus d\'agents que le nombre maximal permis pour le fournisseur de service sélectionné.';
	$msg_arr['soap2_err_910'] = 'Les organisations que vous désirez déplacer possèdent des extensions de callback avec plus d\'afficheurs que la limite autorisée par le fournisseur de service.';
	$msg_arr['soap2_err_911'] = 'Les organisations que vous désirez déplacer possèdent des extensions de carte d\'appels avec plus de codes que la limite autorisée par le fournisseur de service.';
	$msg_arr['soap2_err_912'] = 'Type d\'organisation invalide. Veuillez utiliser un des types suivants: 0 - Affaires, 1 - Groupe résidentiel.';
?>